import base64
import json
import re
import shutil
import subprocess
from pathlib import Path

import httpx


def _hex_to_color_name_pt(hex_str: str) -> str:
    """Converte código HEX em nome de cor amigável em português para IAs de texto."""
    try:
        h = hex_str.lstrip("#")
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    except Exception:
        return "neutro"

    lum = 0.299 * r + 0.587 * g + 0.114 * b
    if lum < 28:
        return "preto/escuro"
    if lum > 228 and max(r, g, b) - min(r, g, b) < 25:
        return "branco/claro"
    if max(r, g, b) - min(r, g, b) < 22:
        return "cinza neutro"
    if r >= g and r >= b:
        if g > 140 and b < 90:
            return "amarelo/dourado"
        if g > 90:
            return "laranja/quente"
        return "vermelho/vinho"
    if g >= r and g >= b:
        if b > 130:
            return "verde-água/ciano"
        return "verde"
    if r > 120:
        return "roxo/lilás"
    return "azul"


def _run_tesseract_ocr(img_path: Path) -> str:
    """Extrai textos reais na tela filtrando por confiança >= 72% (evita falsos positivos em nuvens/texturas)."""
    if not shutil.which("tesseract") or not img_path.exists():
        return ""
    try:
        proc = subprocess.run(
            ["tesseract", str(img_path), "stdout", "-l", "por+eng", "--psm", "11", "tsv"],
            capture_output=True,
            text=True,
            timeout=6,
        )
        if proc.returncode != 0:
            return ""
        words = []
        for idx, line in enumerate(proc.stdout.splitlines()):
            if idx == 0:
                continue
            cols = line.split("\t")
            if len(cols) < 12:
                continue
            try:
                conf = float(cols[10])
            except Exception:
                continue
            token = cols[11].strip("|[]{}()_~`\"'.,;:-—")
            if conf >= 72.0 and len(token) >= 3 and re.search(r"[A-Za-zÀ-ÿ0-9]{3,}", token):
                words.append(token)
        text = " ".join(words)
        return text[:220].strip()
    except Exception:
        return ""


def _build_local_visual_caption(scene: dict, ocr_text: str) -> str:
    vis = scene.get("visual") or {}
    w, h = vis.get("width", 0), vis.get("height", 0)
    orient = "vertical (formato Shorts/TikTok)" if h > w else "horizontal (widescreen)"
    b = vis.get("brightness_pct", 50.0)
    if b < 18:
        light = "ambiente escuro/noturno"
    elif b > 70:
        light = "ambiente bastante claro/iluminado"
    else:
        light = "iluminação equilibrada"

    sharp = vis.get("sharpness_score", 50)
    detail = "alta riqueza de detalhes/bordas nítidas" if sharp >= 65 else (
        "imagem suave/fundo desfocado ou minimalista" if sharp <= 30 else "foco moderado"
    )
    colors = vis.get("dominant_colors") or []
    color_names = []
    for c in colors[:2]:
        cname = _hex_to_color_name_pt(c)
        if cname not in color_names:
            color_names.append(cname)
    pal_str = " e ".join(color_names) if color_names else "variadas"

    desc = f"Quadro {orient} com {light}, {detail} e predominância de tons {pal_str}."
    if ocr_text:
        desc += f' Texto detectado na tela: "{ocr_text}".'
    return desc


def _caption_storyboard_with_groq(storyboard_path: Path, scenes_count: int, api_key: str) -> list[dict] | None:
    if not api_key or not storyboard_path.exists():
        return None
    try:
        b64 = base64.b64encode(storyboard_path.read_bytes()).decode("ascii")
        prompt = (
            f"Esta imagem é um Storyboard numerado de Cena 01 até Cena {scenes_count:02d}. "
            "Para CADA cena, descreva objetivamente em português o que aparece visualmente na fotografia "
            "(pessoas, objetos, cenário, ações, gráficos) e qualquer texto escrito dentro do quadro. "
            "Responda APENAS um JSON válido no formato: "
            '{"scenes":[{"index":1,"visual_description":"...","on_screen_text":"..."}]}'
        )
        resp = httpx.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": f"Bearer {api_key}"},
            json={
                "model": "meta-llama/llama-4-scout-17b-16e-instruct",
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}},
                        ],
                    }
                ],
                "response_format": {"type": "json_object"},
                "temperature": 0.2,
                "max_tokens": 1200,
            },
            timeout=25.0,
        )
        if resp.status_code != 200:
            return None
        content = resp.json()["choices"][0]["message"]["content"]
        parsed = json.loads(content)
        return parsed.get("scenes")
    except Exception:
        return None


def _caption_storyboard_with_gemini(storyboard_path: Path, scenes_count: int, api_key: str) -> list[dict] | None:
    if not api_key or not storyboard_path.exists():
        return None
    try:
        b64 = base64.b64encode(storyboard_path.read_bytes()).decode("ascii")
        prompt = (
            f"Esta imagem é um Storyboard numerado de Cena 01 até Cena {scenes_count:02d}. "
            "Para CADA cena, descreva objetivamente em português o que aparece visualmente na cena "
            "(pessoas, objetos, cenário, ações) e qualquer texto visível dentro do vídeo. "
            "Responda APENAS um JSON válido no formato: "
            '{"scenes":[{"index":1,"visual_description":"...","on_screen_text":"..."}]}'
        )
        resp = httpx.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={api_key}",
            json={
                "contents": [
                    {
                        "parts": [
                            {"text": prompt},
                            {"inline_data": {"mime_type": "image/jpeg", "data": b64}},
                        ]
                    }
                ],
                "generationConfig": {"responseMimeType": "application/json", "temperature": 0.2},
            },
            timeout=25.0,
        )
        if resp.status_code != 200:
            return None
        txt = resp.json()["candidates"][0]["content"]["parts"][0]["text"]
        parsed = json.loads(txt)
        return parsed.get("scenes")
    except Exception:
        return None


def enrich_scenes_with_vision_and_ocr(
    scenes: list[dict],
    scenes_dir: Path,
    storyboard_path: Path,
    groq_api_key: str = "",
    gemini_api_key: str = "",
) -> str:
    """
    Preenche `visual_description` e `ocr_text` em cada cena para que até IAs
    sem suporte a imagem (como web_fetch textual do Claude/Perplexity/ChatGPT)
    saibam exatamente o que aparece na tela e o que está escrito nela!
    Retorna uma string indicando qual motor visual foi usado.
    """
    # 1. Tenta Visão por IA Gratuita (Gemini Flash ou Groq Llama-4-Scout) se chave configurada
    ai_captions = None
    vision_source = "OCR Local (Tesseract) + Análise Visual Nativa"

    if gemini_api_key:
        ai_captions = _caption_storyboard_with_gemini(storyboard_path, len(scenes), gemini_api_key)
        if ai_captions:
            vision_source = "IA de Visão Google Gemini Flash"

    if not ai_captions and groq_api_key:
        ai_captions = _caption_storyboard_with_groq(storyboard_path, len(scenes), groq_api_key)
        if ai_captions:
            vision_source = "IA de Visão Llama-4-Scout (Groq Grátis)"

    ai_map = {}
    if isinstance(ai_captions, list):
        for item in ai_captions:
            if isinstance(item, dict) and item.get("index") is not None:
                ai_map[int(item["index"])] = item

    # 2. Combina descrição por IA (se disponível) ou OCR Tesseract local + heurística
    for sc in scenes:
        idx = sc["index"]
        img_path = scenes_dir / sc["filename"]
        if idx in ai_map:
            v_desc = (ai_map[idx].get("visual_description") or "").strip()
            ocr = (ai_map[idx].get("on_screen_text") or "").strip()
            if not ocr:
                ocr = _run_tesseract_ocr(img_path)
            sc["ocr_text"] = ocr
            sc["visual_description"] = v_desc or _build_local_visual_caption(sc, ocr)
        else:
            ocr = _run_tesseract_ocr(img_path)
            sc["ocr_text"] = ocr
            sc["visual_description"] = _build_local_visual_caption(sc, ocr)

    return vision_source
