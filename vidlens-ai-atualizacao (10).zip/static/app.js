let currentPack = null;

document.addEventListener("DOMContentLoaded", () => {
  initMagicUrls();
  loadHealthAndSettings();
  loadLibrary();
  setupDragAndDrop();
});

function initMagicUrls() {
  const origin = window.location.origin;
  const elConv = document.getElementById("magicUrlConvert");
  const elSearch = document.getElementById("magicUrlSearch");
  if (elConv) {
    elConv.textContent = `${origin}/ai?url=https://www.youtube.com/watch?v=qx4wK0WZteQ`;
  }
  if (elSearch) {
    elSearch.textContent = `${origin}/ai/search?q=inteligencia+artificial+brasil&convert_top=2`;
  }
}

function showToast(msg) {
  const t = document.getElementById("toastMsg");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2600);
}

function setLoading(active, title = "Processando...", sub = "Aguarde alguns segundos...") {
  const box = document.getElementById("loadingBox");
  document.getElementById("loadingTitle").textContent = title;
  document.getElementById("loadingSub").textContent = sub;
  box.classList.toggle("active", active);
  if (active) hideError();
}

function showError(msg) {
  const box = document.getElementById("errorBox");
  box.textContent = "⚠️ " + msg;
  box.classList.add("active");
}

function hideError() {
  const box = document.getElementById("errorBox");
  box.classList.remove("active");
}

function switchMainTab(tabId) {
  document.querySelectorAll(".nav-tab").forEach((b) => {
    b.classList.toggle("active", b.dataset.tab === tabId);
  });
  document.querySelectorAll(".panel").forEach((p) => {
    p.classList.toggle("active", p.id === tabId);
  });
  if (tabId === "tab-library") {
    loadLibrary();
  }
}

function switchSubTab(subId) {
  document.querySelectorAll(".sub-tab").forEach((b) => {
    b.classList.toggle("active", b.dataset.sub === subId);
  });
  document.querySelectorAll(".sub-view").forEach((v) => {
    v.classList.toggle("active", v.id === subId);
  });
}

function openModal(id) {
  document.getElementById(id).classList.add("active");
}

function closeModal(id) {
  document.getElementById(id).classList.remove("active");
}

function escapeHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

async function loadHealthAndSettings() {
  try {
    const [hRes, sRes] = await Promise.all([
      fetch("/api/health"),
      fetch("/api/settings"),
    ]);
    if (hRes.ok) {
      const h = await hRes.json();
      const txt = document.getElementById("engineStatusText");
      if (h.github_vault_configured) {
        txt.textContent = `Motor v3.2 • Cofre Permanente Ativo (${h.cached_packs} vídeos)`;
      } else if (h.groq_configured || h.gemini_configured) {
        txt.textContent = "Motor v3.2 • Visão IA + OCR + Anti-Bloqueio";
      } else {
        txt.textContent = `Motor v3.2 Gratuito Ativo (${h.cached_packs} vídeos)`;
      }
      const vb = document.getElementById("vaultStatusBadge");
      if (vb) {
        if (h.github_vault_configured) {
          vb.style.background = "rgba(16,185,129,0.16)";
          vb.style.borderColor = "rgba(16,185,129,0.45)";
          vb.style.color = "#6ee7b7";
          vb.textContent = "✅ Cofre Permanente Ativo (Vídeos ficam salvos p/ sempre!)";
        } else {
          vb.style.background = "rgba(245,158,11,0.14)";
          vb.style.borderColor = "rgba(245,158,11,0.4)";
          vb.style.color = "#fcd34d";
          vb.textContent = "⏳ Sessão atual (Ative o Cofre em ⚙️ p/ salvar p/ sempre)";
        }
      }
    }
    if (sRes.ok) {
      const s = await sRes.json();
      document.getElementById("cfgMaxScenes").value = String(s.default_max_scenes || 6);
      document.getElementById("cfgLocalWhisper").checked = Boolean(s.enable_local_whisper);
      if (s.groq_api_key_masked) {
        document.getElementById("cfgGroqKey").value = s.groq_api_key_masked;
      }
      if (s.gemini_api_key_masked && document.getElementById("cfgGeminiKey")) {
        document.getElementById("cfgGeminiKey").value = s.gemini_api_key_masked;
      }
      if (document.getElementById("cfgGithubRepo")) {
        document.getElementById("cfgGithubRepo").value = s.github_repo || "rodrihoenzo-arch/Sourcefont.AI";
      }
      if (s.github_token_masked && document.getElementById("cfgGithubToken")) {
        document.getElementById("cfgGithubToken").value = s.github_token_masked;
      }
    }
  } catch (e) {
    console.error(e);
  }
}

async function saveSettings() {
  const maxScenes = parseInt(document.getElementById("cfgMaxScenes").value, 10) || 6;
  const localWhisper = document.getElementById("cfgLocalWhisper").checked;
  const groqKey = document.getElementById("cfgGroqKey").value.trim();
  const geminiEl = document.getElementById("cfgGeminiKey");
  const geminiKey = geminiEl ? geminiEl.value.trim() : "";
  const ghRepo = document.getElementById("cfgGithubRepo") ? document.getElementById("cfgGithubRepo").value.trim() : "";
  const ghToken = document.getElementById("cfgGithubToken") ? document.getElementById("cfgGithubToken").value.trim() : "";

  try {
    const res = await fetch("/api/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        default_max_scenes: maxScenes,
        enable_local_whisper: localWhisper,
        groq_api_key: groqKey,
        gemini_api_key: geminiKey,
        github_repo: ghRepo,
        github_token: ghToken,
      }),
    });
    if (res.ok) {
      closeModal("settingsModal");
      showToast("Configurações salvas com sucesso!");
      loadHealthAndSettings();
    }
  } catch (e) {
    showError("Não foi possível salvar as configurações.");
  }
}

function quickSearch(query, platform) {
  document.getElementById("searchInput").value = query;
  document.getElementById("searchPlatform").value = platform || "all";
  runVideoSearch();
}

async function runVideoSearch() {
  const q = document.getElementById("searchInput").value.trim();
  const platform = document.getElementById("searchPlatform").value;
  if (!q) {
    showError("Digite um assunto para pesquisar vídeos.");
    return;
  }

  document.getElementById("dossierBanner").style.display = "none";
  setLoading(true, `Pesquisando vídeos sobre "${q}"...`, "Consultando YouTube, TikTok e fontes de vídeo da web...");

  try {
    const res = await fetch(`/api/search?q=${encodeURIComponent(q)}&platform=${encodeURIComponent(platform)}&max_results=9`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Falha na pesquisa.");
    renderSearchResults(data.results || []);
  } catch (e) {
    showError(e.message || "Erro ao pesquisar vídeos.");
  } finally {
    setLoading(false);
  }
}

function renderSearchResults(items) {
  const grid = document.getElementById("searchResultsGrid");
  if (!items.length) {
    grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;color:var(--text-secondary);padding:28px;">Nenhum vídeo encontrado para essa busca. Tente termos mais amplos.</div>`;
    return;
  }

  grid.innerHTML = items
    .map((v) => {
      const platClass = `plat-${escapeHtml(v.platform || "web")}`;
      const thumbHtml = v.thumbnail
        ? `<img src="${escapeHtml(v.thumbnail)}" alt="Miniatura" loading="lazy" onerror="this.style.display='none'" />`
        : `<div class="thumb-placeholder">🎬 ${escapeHtml((v.platform || " Vídeo").toUpperCase())}</div>`;
      const actionBtn = v.cached
        ? `<button class="btn btn-emerald btn-sm" style="flex:1" onclick="openPackById('${escapeHtml(v.pack_id)}')">⚡ Abrir do Cache</button>`
        : `<button class="btn btn-primary btn-sm" style="flex:1" onclick="convertVideoUrl('${escapeHtml(v.url)}')">✨ Converter p/ IA</button>`;

      return `
      <div class="video-card">
        <div>
          <div class="thumb-wrap">
            ${thumbHtml}
            <span class="plat-badge ${platClass}">${escapeHtml(v.platform)}</span>
            <span class="dur-badge">${escapeHtml(v.duration_human || "—")}</span>
          </div>
          <div class="card-body">
            <h4 class="card-title" title="${escapeHtml(v.title)}">${escapeHtml(v.title)}</h4>
            <div class="card-meta">👤 ${escapeHtml(v.uploader || "Canal")}</div>
          </div>
        </div>
        <div class="card-footer">
          ${actionBtn}
          <a href="${escapeHtml(v.url)}" target="_blank" rel="noopener" class="btn btn-secondary btn-sm" title="Ver original">↗</a>
        </div>
      </div>`;
    })
    .join("");
}

async function runBatchResearch() {
  const q = document.getElementById("searchInput").value.trim();
  const platform = document.getElementById("searchPlatform").value;
  if (!q) {
    showError("Digite um assunto primeiro para gerar o Dossiê Automático para IA.");
    return;
  }

  setLoading(
    true,
    `Montando Dossiê de Pesquisa em Vídeo para "${q}"...`,
    "Buscando vídeos relevantes, extraindo cenas HD, preservando áudio e unificando transcrições..."
  );

  try {
    const res = await fetch("/api/research-batch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: q, platform, top_n: 2, max_scenes: 6 }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Falha ao criar dossiê.");

    const banner = document.getElementById("dossierBanner");
    const fullUrl = `${window.location.origin}/d/${data.dossier_id}`;
    banner.style.display = "block";
    banner.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
        <div>
          <strong style="color:#f3e8ff;font-size:1rem;">📑 Dossiê Multimodal Pronto (${data.packs.length} vídeos unificados)!</strong>
          <div style="font-size:0.85rem;color:#e9d5ff;margin-top:3px;">Envie este link único para sua IA ler todos os vídeos pesquisados de uma vez: <code>${escapeHtml(fullUrl)}</code></div>
        </div>
        <div style="display:flex;gap:8px;">
          <button class="btn btn-purple btn-sm" onclick="navigator.clipboard.writeText('${escapeHtml(fullUrl)}');showToast('Link do Dossiê copiado!')">🔗 Copiar Link do Dossiê</button>
          <a href="/d/${escapeHtml(data.dossier_id)}" target="_blank" class="btn btn-secondary btn-sm">Abrir Dossiê Completo</a>
        </div>
      </div>
    `;

    if (data.packs && data.packs.length > 0) {
      await openPackById(data.packs[0].pack_id);
    }
    loadHealthAndSettings();
  } catch (e) {
    showError(e.message || "Erro na pesquisa em lote.");
  } finally {
    setLoading(false);
  }
}

async function convertDirectUrl() {
  const url = document.getElementById("directUrlInput").value.trim();
  const maxScenes = parseInt(document.getElementById("directScenesCount").value, 10) || 8;
  if (!url) {
    showError("Cole um link de vídeo válido.");
    return;
  }
  await convertVideoUrl(url, maxScenes);
}

async function convertVideoUrl(url, maxScenes = 8) {
  setLoading(
    true,
    "Convertendo vídeo para formato Multimodal IA...",
    "Baixando mídia, detectando mudanças de cena HD, medindo espectro de áudio e sincronizando transcrição..."
  );

  try {
    const res = await fetch("/api/convert", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url, max_scenes: maxScenes, force_refresh: false }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Falha ao converter vídeo.");
    renderPackViewer(data);
    loadHealthAndSettings();
  } catch (e) {
    showError(e.message || "Erro ao converter vídeo.");
  } finally {
    setLoading(false);
  }
}

function setupDragAndDrop() {
  const dz = document.getElementById("uploadDropzone");
  if (!dz) return;
  dz.addEventListener("dragover", (e) => {
    e.preventDefault();
    dz.classList.add("dragover");
  });
  dz.addEventListener("dragleave", () => dz.classList.remove("dragover"));
  dz.addEventListener("drop", (e) => {
    e.preventDefault();
    dz.classList.remove("dragover");
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  });
}

async function handleFileUpload(file) {
  if (!file) return;
  const customTitle = (document.getElementById("upTitle")?.value || "").trim();
  const authorName = (document.getElementById("upAuthor")?.value || "").trim();
  const notesForAi = (document.getElementById("upNotes")?.value || "").trim();
  const maxScenes = document.getElementById("upScenesCount")?.value || "12";

  setLoading(
    true,
    `Adicionando e convertendo "${customTitle || file.name}"...`,
    "Extraindo quadros HD, medindo movimento entre cenas, analisando áudio e gerando link para IA..."
  );

  const formData = new FormData();
  formData.append("file", file);
  formData.append("max_scenes", maxScenes);
  formData.append("custom_title", customTitle);
  formData.append("author_name", authorName);
  formData.append("notes_for_ai", notesForAi);

  try {
    const res = await fetch("/api/upload", {
      method: "POST",
      body: formData,
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Falha no upload.");
    renderPackViewer(data);
    loadHealthAndSettings();
  } catch (e) {
    showError(e.message || "Erro ao enviar vídeo.");
  } finally {
    setLoading(false);
    document.getElementById("videoFileInput").value = "";
  }
}

async function openPackById(packId) {
  setLoading(true, "Abrindo pacote do cache...", "Carregamento instantâneo...");
  try {
    const res = await fetch(`/api/packs/${encodeURIComponent(packId)}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Pacote não encontrado.");
    renderPackViewer(data);
  } catch (e) {
    showError(e.message);
  } finally {
    setLoading(false);
  }
}

function closePackViewer() {
  document.getElementById("packViewer").classList.remove("active");
}

function renderPackViewer(pack) {
  currentPack = pack;
  const viewer = document.getElementById("packViewer");
  viewer.classList.add("active");

  const platBadge = document.getElementById("pvPlatform");
  platBadge.className = `plat-badge plat-${pack.platform || "web"}`;
  platBadge.textContent = (pack.platform || "web").toUpperCase();

  document.getElementById("pvTitle").textContent = pack.title || "Vídeo Convertido";
  const specs = pack.video_specs || {};
  document.getElementById("pvMeta").innerHTML = `
    👤 <strong>${escapeHtml(pack.uploader)}</strong> &nbsp;•&nbsp;
    ⏱️ ${escapeHtml(pack.duration_human)} &nbsp;•&nbsp;
    🎞️ ${specs.width || 0}×${specs.height || 0} (${(pack.scenes || []).length} cenas HD) &nbsp;•&nbsp;
    🗣️ ${escapeHtml((pack.transcript || {}).source || "—")}
  `;

  document.getElementById("pvReaderOpenBtn").href = `/r/${pack.pack_id}`;
  document.getElementById("pvStoryboardDownload").href = pack.storyboard_url;
  document.getElementById("pvZipDownload").href = `/api/packs/${pack.pack_id}/export.zip`;

  const permBtn = document.getElementById("pvSavePermBtn");
  if (permBtn) {
    if (pack.permanent_saved) {
      permBtn.textContent = "✅ Salvo Permanente";
      permBtn.disabled = true;
    } else {
      permBtn.textContent = "📌 Salvar Permanente";
      permBtn.disabled = false;
    }
  }

  // 1. Cenas
  const scenesGrid = document.getElementById("pvScenesGrid");
  scenesGrid.innerHTML = (pack.scenes || [])
    .map((sc) => {
      const vis = sc.visual || {};
      const aud = sc.audio || {};
      const dots = (vis.dominant_colors || [])
        .map((c) => `<span class="color-dot" style="background:${escapeHtml(c)}" title="${escapeHtml(c)}"></span>`)
        .join("");
      const speech = sc.spoken_text
        ? `"${escapeHtml(sc.spoken_text)}"`
        : `<em style="color:var(--text-muted)">Sem fala transcrita neste trecho</em>`;
      const vDesc = sc.visual_description
        ? `<div style="font-size:0.81rem;color:#bae6fd;margin-bottom:5px;">👁️ ${escapeHtml(sc.visual_description)}</div>`
        : "";
      const mDesc = sc.motion_summary
        ? `<div style="font-size:0.77rem;color:#c4b5fd;margin-bottom:7px;">💨 ${escapeHtml(sc.motion_summary)}</div>`
        : "";

      return `
      <div class="scene-card">
        <a href="${escapeHtml(sc.image_url)}" target="_blank" title="Clique para abrir o quadro em tamanho real">
          <img src="${escapeHtml(sc.image_url)}" alt="Cena ${sc.index}" loading="lazy" />
        </a>
        <div class="scene-info">
          <div class="scene-header">
            <strong>Cena ${String(sc.index).padStart(2, "0")}</strong>
            <span class="scene-time">${escapeHtml(sc.time_range)}</span>
          </div>
          ${vDesc}
          ${mDesc}
          <div class="scene-speech">${speech}</div>
          <div class="scene-telemetry">
            <span>🔊 ${escapeHtml(aud.energy_label || "—")} (${aud.rms_db ?? "—"} dB)</span>
            <span>✨ Nitidez: ${vis.sharpness_score ?? 0}/100</span>
            <span class="color-dots">${dots}</span>
          </div>
        </div>
      </div>`;
    })
    .join("");

  // 2. Storyboard
  document.getElementById("pvStoryboardImg").src = `${pack.storyboard_url}?t=${Date.now()}`;

  // 3. Áudio & Espectrograma
  const audTel = pack.audio_telemetry || {};
  const metricsEl = document.getElementById("pvAudioMetrics");
  const playerWrap = document.getElementById("pvAudioPlayerWrap");
  const specImg = document.getElementById("pvSpectrogramImg");

  if (audTel.available) {
    metricsEl.innerHTML = `
      <div class="metric-box"><div class="metric-label">Volume Médio (RMS)</div><div class="metric-val">${audTel.rms_db} dBFS</div></div>
      <div class="metric-box"><div class="metric-label">Pico Máximo</div><div class="metric-val">${audTel.peak_db} dBFS</div></div>
      <div class="metric-box"><div class="metric-label">Atividade Sonora</div><div class="metric-val">${audTel.active_sound_pct}%</div></div>
      <div class="metric-box"><div class="metric-label">Presença Vocal</div><div class="metric-val">${audTel.voice_band_energy_pct}%</div></div>
      <div class="metric-box" style="grid-column:1/-1"><div class="metric-label">Diagnóstico Acústico p/ IA</div><div class="metric-val" style="font-size:0.98rem;color:#6ee7b7">${escapeHtml(audTel.profile_summary)}</div></div>
    `;
    playerWrap.innerHTML = pack.audio_url
      ? `<div style="background:var(--bg-elevated);padding:12px 16px;border-radius:10px;border:1px solid var(--border);display:flex;flex-wrap:wrap;align-items:center;gap:14px;">
           <strong>🎧 Áudio Original Preservado:</strong>
           <audio controls src="${escapeHtml(pack.audio_url)}" style="flex:1;min-width:240px;"></audio>
           <a href="${escapeHtml(pack.audio_url)}" download="audio-${pack.pack_id}.mp3" class="btn btn-secondary btn-sm">Baixar MP3</a>
         </div>`
      : "";
    specImg.style.display = "block";
    specImg.src = `${pack.spectrogram_url}?t=${Date.now()}`;
  } else {
    metricsEl.innerHTML = `<div class="metric-box"><div class="metric-val">Sem faixa de áudio detectada</div></div>`;
    playerWrap.innerHTML = "";
    specImg.style.display = "none";
  }

  // 4. Markdown p/ IA (reescreve links usando window.location.origin atual)
  const origin = window.location.origin;
  const mdText = (pack.ai_markdown || "").replace(/https?:\/\/[^/\s)]+\/packs\//g, `${origin}/packs/`);
  document.getElementById("pvMarkdownArea").value = mdText;

  switchSubTab("sub-scenes");
  viewer.scrollIntoView({ behavior: "smooth", block: "start" });
}

function copyPromptForAI() {
  if (!currentPack) return;
  const md = document.getElementById("pvMarkdownArea").value;
  const readerUrl = `${window.location.origin}/r/${currentPack.pack_id}`;
  const prompt = `Analise este vídeo convertido pelo VidLens AI (Link com imagens das cenas e áudio: ${readerUrl}). Abaixo estão todos os dados multimodais extraídos (metadados, análise acústica, cenas cronometradas e transcrição):\n\n${md}`;
  navigator.clipboard.writeText(prompt);
  showToast("📋 Relatório + Prompt copiados! Cole direto na sua IA.");
}

async function saveCurrentPackPermanent() {
  if (!currentPack) return;
  const btn = document.getElementById("pvSavePermBtn");
  if (btn) {
    btn.disabled = true;
    btn.textContent = "⏳ Salvando...";
  }
  try {
    const res = await fetch(`/api/packs/${encodeURIComponent(currentPack.pack_id)}/save-permanent`, {
      method: "POST",
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Configure o GITHUB_TOKEN em Configurações.");
    currentPack.permanent_saved = true;
    if (btn) btn.textContent = "✅ Salvo Permanente";
    showToast("📌 Vídeo salvo para sempre no seu Cofre GitHub!");
    loadHealthAndSettings();
  } catch (e) {
    if (btn) {
      btn.disabled = false;
      btn.textContent = "📌 Salvar Permanente";
    }
    showError(e.message);
  }
}

function copyReaderLink() {
  if (!currentPack) return;
  const url = `${window.location.origin}/r/${currentPack.pack_id}`;
  navigator.clipboard.writeText(url);
  showToast("🔗 Link Leitor IA copiado!");
}

async function loadLibrary() {
  const grid = document.getElementById("libraryGrid");
  if (!grid) return;
  try {
    const res = await fetch("/api/packs");
    const data = await res.json();
    const items = data.packs || [];
    if (!items.length) {
      grid.innerHTML = `<div style="grid-column:1/-1;color:var(--text-secondary);padding:18px;background:var(--bg-elevated);border-radius:10px;text-align:center;">Ainda não há vídeos convertidos no cache. Pesquise um tema na primeira aba e clique em "Converter p/ IA"!</div>`;
      return;
    }
    grid.innerHTML = items
      .map(
        (p) => `
      <div class="video-card">
        <div>
          <div class="thumb-wrap">
            <img src="${escapeHtml(p.thumbnail_url || p.storyboard_url)}" alt="Cena" loading="lazy" />
            <span class="plat-badge plat-${escapeHtml(p.platform || "web")}">${escapeHtml(p.platform)}</span>
            <span class="dur-badge">${escapeHtml(p.duration_human || "—")}</span>
          </div>
          <div class="card-body">
            <h4 class="card-title">${escapeHtml(p.title)}</h4>
            <div class="card-meta">👤 ${escapeHtml(p.uploader)} • ${p.scenes_count} cenas</div>
          </div>
        </div>
        <div class="card-footer">
          <button class="btn btn-primary btn-sm" style="flex:1" onclick="openPackById('${escapeHtml(p.pack_id)}')">Abrir Pacote IA</button>
          <button class="btn btn-secondary btn-sm" onclick="removePack('${escapeHtml(p.pack_id)}')" title="Excluir do cache">🗑️</button>
        </div>
      </div>`
      )
      .join("");
  } catch (e) {
    console.error(e);
  }
}

async function removePack(packId) {
  await fetch(`/api/packs/${encodeURIComponent(packId)}`, { method: "DELETE" });
  showToast("Removido do cache.");
  loadLibrary();
  loadHealthAndSettings();
}
