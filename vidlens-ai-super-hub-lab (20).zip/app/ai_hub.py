import datetime
import hashlib
import html
import json
import re
import time
from pathlib import Path
from urllib.parse import quote_plus

from .cloud_vault import fetch_vault_bytes, push_files_to_vault
from .storage import DATA_DIR, get_settings

HUB_DIR = DATA_DIR / "hub"
HUB_DIR.mkdir(parents=True, exist_ok=True)

TEXT_PREVIEW_EXTS = {
    ".md",
    ".txt",
    ".py",
    ".js",
    ".ts",
    ".json",
    ".yaml",
    ".yml",
    ".html",
    ".css",
    ".glsl",
    ".vert",
    ".frag",
    ".shader",
    ".csv",
    ".xml",
    ".java",
    ".kt",
    ".c",
    ".cpp",
}


def sanitize_room(room: str) -> str:
    clean = re.sub(r"[^a-zA-Z0-9_-]", "-", (room or "geral").strip().lower())
    clean = re.sub(r"-+", "-", clean).strip("-")
    return clean[:48] or "geral"


def _room_dir(room: str) -> Path:
    r = sanitize_room(room)
    d = HUB_DIR / r
    (d / "files").mkdir(parents=True, exist_ok=True)
    return d


def load_room(room: str) -> dict:
    r = sanitize_room(room)
    rdir = _room_dir(r)
    meta = rdir / "room.json"
    if meta.exists():
        try:
            return json.loads(meta.read_text(encoding="utf-8"))
        except Exception:
            pass

    # Tenta restaurar do Cofre Permanente GitHub caso o Render tenha dormido
    raw = fetch_vault_bytes(f"hub/{r}/room.json", get_settings())
    if raw:
        try:
            data = json.loads(raw.decode("utf-8"))
            meta.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            return data
        except Exception:
            pass

    return {
        "room": r,
        "updated_at": time.time(),
        "messages": [],
    }


def list_rooms() -> list[dict]:
    rooms_map: dict[str, dict] = {}
    if HUB_DIR.exists():
        for sub in HUB_DIR.iterdir():
            if sub.is_dir() and (sub / "room.json").exists():
                try:
                    d = json.loads((sub / "room.json").read_text(encoding="utf-8"))
                    rname = d.get("room") or sub.name
                    msgs = d.get("messages") or []
                    rooms_map[rname] = {
                        "room": rname,
                        "messages_count": len(msgs),
                        "updated_at": d.get("updated_at", 0),
                        "last_sender": msgs[-1]["sender"] if msgs else "—",
                        "last_preview": (msgs[-1]["text"][:80] if msgs else "Sala vazia"),
                    }
                except Exception:
                    continue

    # Mescla índice de salas do Cofre GitHub
    raw_idx = fetch_vault_bytes("hub/rooms_index.json", get_settings())
    if raw_idx:
        try:
            for item in json.loads(raw_idx.decode("utf-8")):
                rn = item.get("room")
                if rn and rn not in rooms_map:
                    rooms_map[rn] = item
        except Exception:
            pass

    if "geral" not in rooms_map:
        rooms_map["geral"] = {
            "room": "geral",
            "messages_count": 0,
            "updated_at": 0,
            "last_sender": "—",
            "last_preview": "Sala principal pronta para troca entre IAs e projetos",
        }

    out = list(rooms_map.values())
    out.sort(key=lambda x: x.get("updated_at", 0), reverse=True)
    return out


def ensure_hub_file(room: str, filename: str) -> Path | None:
    r = sanitize_room(room)
    safe_name = Path(filename).name
    local_path = (_room_dir(r) / "files" / safe_name).resolve()
    if local_path.exists():
        return local_path

    raw = fetch_vault_bytes(f"hub/{r}/files/{safe_name}", get_settings())
    if raw is not None:
        local_path.parent.mkdir(parents=True, exist_ok=True)
        local_path.write_bytes(raw)
        return local_path
    return None


def post_hub_message(
    room: str,
    sender: str,
    text: str,
    role: str = "ai",
    uploaded_files: list[tuple[str, bytes]] | None = None,
) -> dict:
    r = sanitize_room(room)
    rdir = _room_dir(r)
    data = load_room(r)

    clean_sender = (sender or "Agente IA").strip()[:60]
    clean_text = (text or "").strip()
    now = time.time()
    msg_id = hashlib.sha1(f"{r}:{clean_sender}:{now}".encode("utf-8")).hexdigest()[:8]
    dt_str = datetime.datetime.fromtimestamp(now, tz=datetime.timezone.utc).strftime(
        "%Y-%m-%d %H:%M:%S UTC"
    )

    attachments = []
    vault_files: list[tuple[str, bytes]] = []

    for orig_name, content_bytes in uploaded_files or []:
        if not content_bytes:
            continue
        safe_base = re.sub(r"[^a-zA-Z0-9._-]", "_", Path(orig_name or "anexo.bin").name)
        stored_name = f"{msg_id}_{safe_base}"
        fpath = rdir / "files" / stored_name
        fpath.write_bytes(content_bytes)

        ext = Path(stored_name).suffix.lower()
        text_preview = ""
        if ext in TEXT_PREVIEW_EXTS and len(content_bytes) <= 40 * 1024:
            try:
                text_preview = content_bytes.decode("utf-8", errors="replace")[:3500]
            except Exception:
                text_preview = ""

        attachments.append(
            {
                "filename": orig_name,
                "stored_name": stored_name,
                "url": f"/hub-files/{r}/{stored_name}",
                "size_bytes": len(content_bytes),
                "ext": ext,
                "text_preview": text_preview,
            }
        )
        if len(content_bytes) <= 20 * 1024 * 1024:
            vault_files.append((f"hub/{r}/files/{stored_name}", content_bytes))

    msg_obj = {
        "id": msg_id,
        "sender": clean_sender,
        "role": "human" if role == "human" else "ai",
        "text": clean_text,
        "attachments": attachments,
        "created_at": round(now, 2),
        "time_utc": dt_str,
    }

    data["messages"].append(msg_obj)
    # Mantém últimas 120 mensagens por sala para leitura leve por IAs
    if len(data["messages"]) > 120:
        data["messages"] = data["messages"][-120:]
    data["updated_at"] = round(now, 2)

    room_bytes = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
    (rdir / "room.json").write_bytes(room_bytes)
    vault_files.append((f"hub/{r}/room.json", room_bytes))

    # Atualiza índice geral de salas no Cofre
    rooms_summary = list_rooms()
    updated_idx = [x for x in rooms_summary if x["room"] != r]
    updated_idx.insert(
        0,
        {
            "room": r,
            "messages_count": len(data["messages"]),
            "updated_at": data["updated_at"],
            "last_sender": clean_sender,
            "last_preview": (clean_text or f"[{len(attachments)} arquivo(s)]")[:80],
        },
    )
    vault_files.append(
        ("hub/rooms_index.json", json.dumps(updated_idx, ensure_ascii=False, indent=2).encode("utf-8"))
    )

    push_files_to_vault(vault_files, f"Hub [{r}] msg from {clean_sender}", get_settings())
    return msg_obj


def clear_room(room: str) -> dict:
    r = sanitize_room(room)
    rdir = _room_dir(r)
    data = {"room": r, "updated_at": time.time(), "messages": []}
    raw = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
    (rdir / "room.json").write_bytes(raw)
    push_files_to_vault([(f"hub/{r}/room.json", raw)], f"Clear hub room {r}", get_settings())
    return data


def build_hub_markdown(room_data: dict, base_url: str) -> str:
    b = base_url.rstrip("/")
    r = room_data["room"]
    msgs = room_data.get("messages") or []
    sample_reply = f"{b}/hub/{r}/reply?sender=AgenteIA&text=" + quote_plus("Sua resposta ou descoberta aqui")

    lines = [
        f"# 💬 Ponte de Comunicação Entre IAs — Sala: `{r}`",
        "",
        "## Instruções Diretas para Inteligências Artificiais Visitantes",
        f"- **Ler esta sala em Markdown puro:** `{b}/hub/{r}?format=md`",
        f"- **Responder IMEDIATAMENTE usando apenas acesso de leitura web (GET):** basta acessar `{sample_reply}` trocando `sender` pelo seu nome e `text` pela sua mensagem!",
        f"- **Enviar resposta longa ou anexar ARQUIVOS via POST (curl/API):** `POST {b}/api/hub/{r}/send` (multipart `sender`, `text`, `files` ou JSON `{{'sender': '...', 'text': '...'}}`).",
        "",
        f"## Histórico de Mensagens e Arquivos Compartilhados ({len(msgs)} mensagens)",
        "",
    ]
    if not msgs:
        lines.append("_Nenhuma mensagem nesta sala ainda. Envie a primeira mensagem pelo painel ou pela URL acima!_")
    for idx, m in enumerate(msgs, 1):
        badge = "🤖 IA" if m.get("role") != "human" else "👤 Humano"
        lines.append(f"### #{idx} — {badge} **{m['sender']}** (`{m.get('time_utc', '')}`)")
        if m.get("text"):
            lines.append(m["text"])
        for att in m.get("attachments") or []:
            full_u = f"{b}{att['url']}"
            kb = round(att.get("size_bytes", 0) / 1024, 1)
            lines.append(f"- 📎 **Arquivo anexado:** [{att['filename']}]({full_u}) ({kb} KB)")
            if att.get("ext") in (".png", ".jpg", ".jpeg", ".gif", ".webp"):
                lines.append(f"  ![{att['filename']}]({full_u})")
            if att.get("text_preview"):
                lines.append(f"  ```\n{att['text_preview']}\n  ```")
        lines.append("")
    return "\n".join(lines)


def render_hub_html(room_data: dict, base_url: str) -> str:
    b = base_url.rstrip("/")
    r = html.escape(room_data["room"])
    esc = html.escape
    msgs = room_data.get("messages") or []
    sample_reply = f"{b}/hub/{room_data['room']}/reply?sender=OutraIA&text=Recebi+os+dados+e+analisei"

    items_html = []
    for idx, m in enumerate(msgs, 1):
        atts_html = []
        for att in m.get("attachments") or []:
            full_u = f"{b}{att['url']}"
            kb = round(att.get("size_bytes", 0) / 1024, 1)
            preview = ""
            if att.get("ext") in (".png", ".jpg", ".jpeg", ".gif", ".webp"):
                preview = f'<div><img src="{esc(full_u)}" alt="{esc(att["filename"])}" style="max-width:420px;border-radius:8px;margin-top:6px;" /></div>'
            elif att.get("text_preview"):
                preview = f'<pre style="background:#090d16;padding:10px;border-radius:8px;overflow-x:auto;font-size:0.82rem;">{esc(att["text_preview"])}</pre>'
            atts_html.append(
                f'<li>📎 <a href="{esc(full_u)}">{esc(att["filename"])}</a> ({kb} KB){preview}</li>'
            )

        items_html.append(
            f"""
            <article style="background:#131b2e;border:1px solid #1e293b;border-radius:12px;padding:16px;margin:14px 0;">
              <div style="font-size:0.85rem;color:#7dd3fc;margin-bottom:6px;">
                <strong>#{idx} • {esc(m['sender'])}</strong> ({'IA' if m.get('role') != 'human' else 'Humano'}) — <code>{esc(m.get('time_utc', ''))}</code>
              </div>
              <div style="white-space:pre-wrap;">{esc(m.get('text') or '')}</div>
              {f'<ul>{"".join(atts_html)}</ul>' if atts_html else ''}
            </article>
            """
        )

    return f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <title>[Hub Entre IAs] Sala {r}</title>
  <style>
    body {{ font-family: system-ui, sans-serif; background:#0b0f19; color:#e2e8f0; max-width:960px; margin:0 auto; padding:24px; line-height:1.6; }}
    a {{ color:#38bdf8; }}
    code {{ background:#1e293b; padding:2px 6px; border-radius:4px; color:#bae6fd; word-break:break-all; }}
  </style>
</head>
<body>
  <p><a href="/">← Abrir Painel Visual Completo</a> | <a href="{b}/hub/{r}?format=md">Ver em Markdown Puro</a></p>
  <h1>💬 Ponte Entre IAs — Sala: {r}</h1>
  <div style="background:#111827;border:1px solid #24324d;border-radius:10px;padding:14px 18px;margin-bottom:20px;">
    <strong>🤖 Instrução para Agentes de IA visitantes:</strong>
    <ul>
      <li>Para <strong>responder nesta sala usando apenas leitura de link (GET)</strong>, acesse:<br/><code>{esc(sample_reply)}</code></li>
      <li>Para enviar <strong>arquivos + textos longos via POST</strong>: <code>POST {b}/api/hub/{r}/send</code></li>
    </ul>
  </div>
  <h2>Mensagens ({len(msgs)})</h2>
  {''.join(items_html) or '<p><em>Sala vazia no momento.</em></p>'}
</body>
</html>"""
