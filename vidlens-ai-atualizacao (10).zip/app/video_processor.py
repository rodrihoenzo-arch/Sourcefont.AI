import math
import os
import re
import shutil
import subprocess
import tempfile
import time
import wave
from pathlib import Path

import numpy as np
import yt_dlp
from PIL import Image, ImageDraw, ImageFont

from .search_engine import detect_platform, format_duration
from .storage import (
    get_pack_dir,
    get_settings,
    load_pack,
    make_pack_id,
    normalize_video_url,
    save_pack,
)
from .transcriber import extract_best_transcript
from .vision_captioner import enrich_scenes_with_vision_and_ocr


class VideoConversionError(Exception):
    """Erro amigável durante download ou conversão do vídeo."""


def _probe_video_duration_and_info(video_path: Path) -> dict:
    cmd = [
        "ffprobe",
        "-v",
        "error",
        "-show_entries",
        "format=duration:stream=codec_type,codec_name,width,height,r_frame_rate,sample_rate,channels",
        "-of",
        "json",
        str(video_path),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    import json

    info = {
        "duration": 0.0,
        "width": 0,
        "height": 0,
        "video_codec": "unknown",
        "audio_codec": "none",
        "sample_rate": 0,
        "channels": 0,
        "fps": 0.0,
    }
    if proc.returncode != 0:
        return info
    try:
        data = json.loads(proc.stdout)
        fmt = data.get("format") or {}
        if fmt.get("duration"):
            info["duration"] = float(fmt["duration"])
        for st in data.get("streams") or []:
            ctype = st.get("codec_type")
            if ctype == "video" and info["width"] == 0:
                info["width"] = int(st.get("width") or 0)
                info["height"] = int(st.get("height") or 0)
                info["video_codec"] = st.get("codec_name") or "h264"
                fps_raw = st.get("r_frame_rate") or "0/1"
                if "/" in fps_raw:
                    n, d = fps_raw.split("/", 1)
                    if float(d) > 0:
                        info["fps"] = round(float(n) / float(d), 2)
            elif ctype == "audio" and info["audio_codec"] == "none":
                info["audio_codec"] = st.get("codec_name") or "aac"
                info["sample_rate"] = int(st.get("sample_rate") or 0)
                info["channels"] = int(st.get("channels") or 0)
    except Exception:
        pass
    return info


def _download_video_with_ytdlp(url: str, tmp_dir: Path) -> tuple[Path, dict, list[Path]]:
    """Baixa vídeo + legendas com múltiplos fallbacks para YouTube, TikTok, Reels e Web."""
    norm_url = normalize_video_url(url)
    plat = detect_platform(norm_url)

    common_sub_opts = {
        "writesubtitles": True,
        "writeautomaticsub": True,
        "subtitleslangs": ["pt.*", "por.*", "en.*", "eng.*", "es.*", "spa.*"],
        "subtitlesformat": "vtt/srt/best",
    }

    if plat == "youtube":
        attempts = [
            {
                "quiet": True,
                "no_warnings": True,
                "noplaylist": True,
                "socket_timeout": 12,
                "retries": 1,
                "js_runtimes": {"node": {}},
                "extractor_args": {"youtube": {"player_client": ["android"]}},
                "format": "18/best[height<=480][ext=mp4]/best[height<=480]/best",
                "merge_output_format": "mp4",
                "outtmpl": str(tmp_dir / "source.%(ext)s"),
                "max_filesize": 120 * 1024 * 1024,
            },
            {
                "quiet": True,
                "no_warnings": True,
                "noplaylist": True,
                "socket_timeout": 12,
                "retries": 1,
                "extractor_args": {"youtube": {"player_client": ["android"]}},
                "format": "18/best",
                "outtmpl": str(tmp_dir / "source.%(ext)s"),
            },
        ]
    else:
        attempts = [
            {
                "quiet": True,
                "no_warnings": True,
                "noplaylist": True,
                "socket_timeout": 12,
                "retries": 1,
                "js_runtimes": {"node": {}},
                "format": "best[width<=580][vcodec^=avc1]/best[width<=580][ext=mp4]/best[height<=480][ext=mp4]/best[width<=720]/best",
                "merge_output_format": "mp4",
                "outtmpl": str(tmp_dir / "source.%(ext)s"),
                "max_filesize": 120 * 1024 * 1024,
                **common_sub_opts,
            },
            {
                "quiet": True,
                "no_warnings": True,
                "noplaylist": True,
                "socket_timeout": 12,
                "retries": 1,
                "format": "best[width<=580]/best[height<=480]/best",
                "outtmpl": str(tmp_dir / "source.%(ext)s"),
            },
        ]

    last_err = ""
    info = None
    for opts in attempts:
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(norm_url, download=True)
                break
        except Exception as e:
            last_err = str(e)
            continue

    if info is None:
        low_err = last_err.lower()
        if plat == "instagram" and ("login" in low_err or "cookie" in low_err or "unavailable" in low_err or "rate-limit" in low_err):
            raise VideoConversionError(
                "O Instagram bloqueou o acesso anônimo a este Reel (a Meta exige login para muitos links). "
                "Dica simples: baixe o vídeo no seu aparelho e envie na aba 'Enviar Arquivo (.mp4)' para converter sem bloqueios!"
            )
        if "private" in low_err:
            raise VideoConversionError("Este vídeo é privado e não pode ser acessado publicamente.")
        raise VideoConversionError(
            f"Não foi possível baixar o vídeo automaticamente deste link ({plat}). "
            f"Você também pode enviar o arquivo de vídeo direto na aba de Upload. Detalhe técnico: {last_err[:180]}"
        )

    # Localiza o arquivo de vídeo e eventuais legendas .vtt/.srt
    video_exts = {".mp4", ".mkv", ".webm", ".mov", ".m4v", ".avi"}
    sub_exts = {".vtt", ".srt"}
    video_file = None
    sub_files = []
    for f in sorted(tmp_dir.iterdir()):
        if f.suffix.lower() in video_exts and f.stat().st_size > 1024:
            video_file = f
        elif f.suffix.lower() in sub_exts and f.stat().st_size > 10:
            sub_files.append(f)

    if not video_file:
        raise VideoConversionError("O link foi lido, mas nenhum fluxo de vídeo válido foi encontrado.")

    return video_file, info, sub_files


def _compute_frame_metrics(img_path: Path) -> dict:
    """Mede nitidez, brilho, resolução e cores dominantes de um quadro."""
    try:
        with Image.open(img_path) as im:
            rgb = im.convert("RGB")
            w, h = rgb.size
            small = rgb.resize((160, max(90, int(160 * h / max(w, 1)))))
            arr = np.asarray(small, dtype=np.float32)
            gray = 0.299 * arr[:, :, 0] + 0.587 * arr[:, :, 1] + 0.114 * arr[:, :, 2]

            brightness = float(np.mean(gray) / 255.0 * 100.0)
            # Energia de gradiente como indicador de nitidez (0-100)
            gx = np.abs(np.diff(gray, axis=1))
            gy = np.abs(np.diff(gray, axis=0))
            grad_energy = float(np.mean(gx) + np.mean(gy))
            sharpness = min(100, int(round(grad_energy * 3.4)))

            # Cores dominantes por quantização rápida
            pal = small.quantize(colors=3)
            palette = pal.getpalette()[:9]
            hex_colors = []
            for i in range(0, len(palette), 3):
                hex_colors.append(f"#{palette[i]:02x}{palette[i+1]:02x}{palette[i+2]:02x}")

            return {
                "width": w,
                "height": h,
                "brightness_pct": round(brightness, 1),
                "sharpness_score": sharpness,
                "dominant_colors": hex_colors,
            }
    except Exception:
        return {
            "width": 0,
            "height": 0,
            "brightness_pct": 50.0,
            "sharpness_score": 50,
            "dominant_colors": ["#334155"],
        }


def _extract_single_frame(video_path: Path, timestamp: float, out_path: Path) -> bool:
    cmd = [
        "ffmpeg",
        "-y",
        "-hide_banner",
        "-loglevel",
        "error",
        "-ss",
        f"{max(0.0, timestamp):.3f}",
        "-i",
        str(video_path),
        "-vf",
        "scale='min(960,iw)':-2",
        "-frames:v",
        "1",
        "-q:v",
        "3",
        str(out_path),
    ]
    proc = subprocess.run(cmd, capture_output=True, timeout=25)
    return proc.returncode == 0 and out_path.exists() and out_path.stat().st_size > 200


def _extract_scene_keyframes(
    video_path: Path, duration: float, scenes_dir: Path, max_scenes: int = 8
) -> list[dict]:
    """
    Detecta cortes reais de cena via FFmpeg e garante cobertura completa do vídeo.
    Se o vídeo for um plano único sem cortes, amostra quadros distribuídos no tempo.
    """
    scenes_dir.mkdir(parents=True, exist_ok=True)
    effective_dur = min(duration, 600.0) if duration > 0 else 30.0
    min_gap = max(1.8, effective_dur / max(max_scenes * 2.2, 10))

    raw_dir = scenes_dir / "_raw"
    raw_dir.mkdir(parents=True, exist_ok=True)

    vf_expr = (
        f"select='isnan(prev_selected_t)+gte(t-prev_selected_t,{min_gap:.2f})*gt(scene,0.16)',"
        "scale='min(720,iw)':-2,showinfo"
    )
    cmd = [
        "ffmpeg",
        "-y",
        "-hide_banner",
        "-skip_frame",
        "nokey",
        "-t",
        f"{effective_dur:.2f}",
        "-i",
        str(video_path),
        "-vf",
        vf_expr,
        "-vsync",
        "vfr",
        "-q:v",
        "4",
        str(raw_dir / "raw_%03d.jpg"),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=45)
    pts_times = [float(m) for m in re.findall(r"pts_time:([0-9.]+)", proc.stderr)]
    raw_files = sorted(raw_dir.glob("raw_*.jpg"))

    candidates: list[tuple[float, Path | None]] = []
    for idx, rf in enumerate(raw_files):
        t = pts_times[idx] if idx < len(pts_times) else (idx * min_gap)
        candidates.append((t, rf))

    # Se teve poucos cortes visuais (ex: pessoa falando parada), complementa com pontos uniformes
    target_min = min(max_scenes, max(4, int(effective_dur // 6) + 1))
    if len(candidates) < target_min and effective_dur > 2.0:
        shutil.rmtree(raw_dir, ignore_errors=True)
        raw_dir.mkdir(parents=True, exist_ok=True)
        candidates = []
        n_pts = min(max_scenes, max(4, target_min))
        for i in range(n_pts):
            t = round((effective_dur * (i + 0.35)) / n_pts, 2)
            t = min(max(0.2, t), max(0.2, effective_dur - 0.3))
            candidates.append((t, None))

    # Se detectou mais cenas que max_scenes, seleciona uniformemente preservando início, meio e fim
    if len(candidates) > max_scenes:
        idxs = np.linspace(0, len(candidates) - 1, max_scenes, dtype=int)
        seen_idx = []
        for ii in idxs:
            if int(ii) not in seen_idx:
                seen_idx.append(int(ii))
        candidates = [candidates[i] for i in seen_idx]

    final_scenes = []
    for i, (ts, existing_file) in enumerate(candidates, start=1):
        out_name = f"scene_{i:02d}.jpg"
        out_path = scenes_dir / out_name
        if existing_file and existing_file.exists():
            shutil.copy2(existing_file, out_path)
        else:
            _extract_single_frame(video_path, ts, out_path)

        if not out_path.exists():
            continue

        metrics = _compute_frame_metrics(out_path)
        # Se o 1º frame em t≈0 for tela preta de fade-in, avança 0.9s para capturar imagem útil
        if i == 1 and ts < 0.4 and metrics["brightness_pct"] < 5.0 and effective_dur > 2.0:
            new_ts = min(1.0, effective_dur * 0.15)
            if _extract_single_frame(video_path, new_ts, out_path):
                ts = new_ts
                metrics = _compute_frame_metrics(out_path)

        final_scenes.append(
            {
                "index": i,
                "start_sec": round(ts, 2),
                "end_sec": round(effective_dur, 2),  # Ajustado logo abaixo
                "filename": out_name,
                "visual": metrics,
            }
        )

    shutil.rmtree(raw_dir, ignore_errors=True)

    # Ajusta o end_sec de cada cena para o início da próxima
    for i in range(len(final_scenes)):
        if i + 1 < len(final_scenes):
            final_scenes[i]["end_sec"] = final_scenes[i + 1]["start_sec"]
        else:
            final_scenes[i]["end_sec"] = round(max(effective_dur, final_scenes[i]["start_sec"] + 1.0), 2)
        final_scenes[i]["time_range"] = (
            f"{format_duration(final_scenes[i]['start_sec'])} – {format_duration(final_scenes[i]['end_sec'])}"
        )

    return final_scenes


def _extract_and_analyze_audio(
    video_path: Path, pack_dir: Path, scenes: list[dict], has_audio: bool
) -> tuple[dict, Path | None, Path | None]:
    """
    Preserva o áudio em alta qualidade (MP3 VBR ~190kbps), mede telemetria acústica real
    (dBFS, dinâmica, silêncio, frequências) e desenha o Espectrograma + Forma de Onda (spectrogram.png).
    """
    if not has_audio:
        return (
            {
                "available": False,
                "profile_summary": "Vídeo sem faixa de áudio",
            },
            None,
            None,
        )

    mp3_path = pack_dir / "audio.mp3"
    wav_path = pack_dir / "_temp_16k.wav"
    spec_path = pack_dir / "spectrogram.png"

    # 1. Áudio preservado otimizado p/ CPUs leves (até 10 min)
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-t",
            "600",
            "-i",
            str(video_path),
            "-vn",
            "-ac",
            "1",
            "-ar",
            "24000",
            "-acodec",
            "libmp3lame",
            "-q:a",
            "5",
            str(mp3_path),
        ],
        capture_output=True,
        timeout=40,
    )

    # 2. WAV 16kHz mono para análise científica e Faster-Whisper
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-t",
            "420",
            "-i",
            str(video_path),
            "-vn",
            "-ac",
            "1",
            "-ar",
            "16000",
            "-f",
            "wav",
            str(wav_path),
        ],
        capture_output=True,
        timeout=60,
    )

    if not wav_path.exists() or wav_path.stat().st_size < 1000:
        return (
            {
                "available": mp3_path.exists(),
                "profile_summary": "Áudio extraído, mas muito curto para análise espectral",
            },
            mp3_path if mp3_path.exists() else None,
            None,
        )

    try:
        with wave.open(str(wav_path), "rb") as wf:
            sr = wf.getframerate()
            n_frames = wf.getnframes()
            raw_bytes = wf.readframes(n_frames)
        samples = np.frombuffer(raw_bytes, dtype=np.int16).astype(np.float32) / 32768.0
    except Exception:
        samples = np.zeros(16000, dtype=np.float32)
        sr = 16000

    if len(samples) < 100:
        samples = np.zeros(16000, dtype=np.float32)

    eps = 1e-9
    rms = float(np.sqrt(np.mean(samples**2)) + eps)
    peak = float(np.max(np.abs(samples)) + eps)
    rms_db = round(20.0 * math.log10(rms), 1)
    peak_db = round(20.0 * math.log10(peak), 1)

    # Janelas de 100ms para detectar silêncio vs som ativo
    win = max(1, sr // 10)
    n_wins = len(samples) // win
    if n_wins > 0:
        framed = samples[: n_wins * win].reshape(n_wins, win)
        win_rms_db = 20.0 * np.log10(np.sqrt(np.mean(framed**2, axis=1)) + eps)
        active_pct = round(float(np.mean(win_rms_db > -42.0) * 100.0), 1)
        p95 = float(np.percentile(win_rms_db, 95))
        p10 = float(np.percentile(win_rms_db, 10))
        dyn_range = round(max(0.0, p95 - p10), 1)
    else:
        active_pct = 0.0
        dyn_range = 0.0

    # Análise espectral (FFT) para medir brilho/ruído agudo vs faixa vocal (300Hz-3400Hz)
    n_fft = 512
    hop = 256
    max_spec_samples = min(len(samples), sr * 180)
    sub = samples[:max_spec_samples]
    n_cols = max(1, (len(sub) - n_fft) // hop)
    if n_cols > 1200:
        hop = max(256, (len(sub) - n_fft) // 1200)
        n_cols = max(1, (len(sub) - n_fft) // hop)

    hann = np.hanning(n_fft).astype(np.float32)
    spec_cols = []
    for c in range(n_cols):
        seg = sub[c * hop : c * hop + n_fft]
        if len(seg) < n_fft:
            break
        mag = np.abs(np.fft.rfft(seg * hann))
        spec_cols.append(mag)

    if spec_cols:
        spec_mat = np.stack(spec_cols, axis=1)  # (freq_bins, time_cols)
        freqs = np.fft.rfftfreq(n_fft, d=1.0 / sr)
        total_energy = float(np.sum(spec_mat) + eps)
        voice_band = (freqs >= 250) & (freqs <= 3600)
        high_band = freqs > 4500
        voice_band_pct = round(float(np.sum(spec_mat[voice_band, :]) / total_energy * 100.0), 1)
        high_freq_pct = round(float(np.sum(spec_mat[high_band, :]) / total_energy * 100.0), 1)
    else:
        spec_mat = np.zeros((257, 100), dtype=np.float32)
        voice_band_pct = 0.0
        high_freq_pct = 0.0

    # Classificação interpretável para a IA
    if active_pct < 8.0 or rms_db < -45.0:
        summary = "Quase silencioso / som ambiente muito baixo"
    elif voice_band_pct >= 58.0 and high_freq_pct < 18.0:
        summary = "Áudio limpo com forte presença de voz humana nítida"
    elif high_freq_pct >= 26.0:
        summary = "Áudio brilhante/intenso (música energética ou ruído/chiado em altas frequências)"
    else:
        summary = "Mix equilibrado de voz, trilha musical e som ambiente"

    # Métrica acústica individual por cena
    for sc in scenes:
        i0 = int(sc["start_sec"] * sr)
        i1 = int(sc["end_sec"] * sr)
        seg = samples[i0:i1] if i1 > i0 and i0 < len(samples) else np.array([], dtype=np.float32)
        if len(seg) > 100:
            s_rms = float(np.sqrt(np.mean(seg**2)) + eps)
            s_db = round(20.0 * math.log10(s_rms), 1)
            if s_db > -18.0:
                label = "Som forte / fala ativa"
            elif s_db > -34.0:
                label = "Volume moderado"
            else:
                label = "Pausa / som baixo"
        else:
            s_db = rms_db
            label = "Trecho curto"
        sc["audio"] = {"rms_db": s_db, "energy_label": label}

    # Desenha imagem visual do áudio (Waveform + Espectrograma) para IAs de Visão
    _render_spectrogram_image(samples, sr, spec_mat, spec_path, rms_db, summary)

    telemetry = {
        "available": True,
        "format_preserved": "MP3 Alta Qualidade (~190 kbps VBR)",
        "rms_db": rms_db,
        "peak_db": peak_db,
        "dynamic_range_db": dyn_range,
        "active_sound_pct": active_pct,
        "voice_band_energy_pct": voice_band_pct,
        "high_freq_energy_pct": high_freq_pct,
        "profile_summary": summary,
    }
    return telemetry, (mp3_path if mp3_path.exists() else None), wav_path


def _load_font(size: int = 12, bold: bool = False):
    candidates = (
        [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        ]
        if bold
        else [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        ]
    )
    for fp in candidates:
        if os.path.exists(fp):
            try:
                return ImageFont.truetype(fp, size=size)
            except Exception:
                pass
    return ImageFont.load_default()


def _render_spectrogram_image(
    samples: np.ndarray,
    sr: int,
    spec_mat: np.ndarray,
    out_path: Path,
    rms_db: float,
    summary: str,
) -> None:
    width, height = 1000, 320
    img = Image.new("RGB", (width, height), (11, 15, 25))
    draw = ImageDraw.Draw(img)
    f_bold = _load_font(13, bold=True)
    f_reg = _load_font(12, bold=False)

    # Cabeçalho
    draw.rectangle([0, 0, width, 36], fill=(19, 26, 43))
    draw.text(
        (14, 10),
        f"MAPA ACÚSTICO DO ÁUDIO (Forma de Onda + Espectrograma 0–8 kHz)  •  Volume Médio: {rms_db} dBFS  •  {summary[:55]}",
        fill=(226, 232, 240),
        font=f_bold,
    )

    # Painel superior: Forma de onda (y: 44..136)
    wf_top, wf_bot = 44, 136
    wf_mid = (wf_top + wf_bot) // 2
    draw.rectangle([12, wf_top, width - 12, wf_bot], fill=(15, 23, 42), outline=(30, 41, 59))
    draw.line([(12, wf_mid), (width - 12, wf_mid)], fill=(30, 41, 59), width=1)

    plot_w = width - 28
    step = max(1, len(samples) // plot_w)
    for x in range(plot_w):
        chunk = samples[x * step : (x + 1) * step]
        if len(chunk) == 0:
            continue
        amp = min(1.0, float(np.max(np.abs(chunk))))
        half_h = int(amp * ((wf_bot - wf_top) / 2 - 4))
        draw.line(
            [(14 + x, wf_mid - half_h), (14 + x, wf_mid + half_h)],
            fill=(56, 189, 248),
            width=1,
        )
    draw.text((20, wf_top + 6), "Forma de Onda (Amplitude)", fill=(148, 163, 184), font=f_reg)

    # Painel inferior: Espectrograma (y: 146..292)
    sp_top, sp_bot = 146, 292
    sp_h = sp_bot - sp_top
    log_spec = np.log10(spec_mat[::-1, :] + 1e-5)
    vmin, vmax = float(np.percentile(log_spec, 12)), float(np.percentile(log_spec, 99.2))
    norm = np.clip((log_spec - vmin) / max(vmax - vmin, 1e-4), 0.0, 1.0)

    # Colormap estilo Magma/Inferno (preto -> roxo -> laranja -> amarelo claro)
    r_ch = np.clip(norm * 1.6, 0, 1) ** 0.85 * 255
    g_ch = np.clip((norm - 0.35) * 1.55, 0, 1) * 245
    b_ch = np.clip(np.sin(norm * math.pi) * 180 + (norm**3) * 140, 0, 255)
    rgb_spec = np.stack([r_ch, g_ch, b_ch], axis=-1).astype(np.uint8)
    spec_pil = Image.fromarray(rgb_spec, mode="RGB").resize((plot_w, sp_h), Image.Resampling.BILINEAR)
    img.paste(spec_pil, (14, sp_top))
    draw.rectangle([12, sp_top, width - 12, sp_bot], outline=(30, 41, 59))
    draw.text((20, sp_top + 6), "Espectrograma de Frequências (Agudos no topo / Graves na base)", fill=(248, 250, 252), font=f_reg)

    # Régua de tempo no rodapé
    dur_s = len(samples) / max(sr, 1)
    for frac in (0.0, 0.25, 0.5, 0.75, 1.0):
        tx = int(14 + frac * (plot_w - 38))
        draw.text((tx, 297), format_duration(dur_s * frac), fill=(148, 163, 184), font=f_reg)

    img.save(out_path, "PNG", optimize=True)


def _align_transcript_to_scenes(scenes: list[dict], segments: list[dict]) -> None:
    """Associa cada fala exatamente à cena visual em que ela ocorre."""
    for sc in scenes:
        s0 = sc["start_sec"]
        s1 = sc["end_sec"]
        matched = []
        for seg in segments:
            mid = (seg["start"] + seg["end"]) / 2.0
            # Verifica sobreposição ou ponto médio dentro da cena
            if (s0 <= mid < s1) or (seg["start"] < s1 and seg["end"] > s0 and (s1 - s0) < 3.0):
                matched.append(seg["text"])
        sc["spoken_text"] = " ".join(matched).strip()


def _render_storyboard(
    scenes: list[dict], scenes_dir: Path, out_path: Path, title: str, platform: str, duration_human: str
) -> None:
    """Gera uma prancha única HD (Contact Sheet) com todas as cenas numeradas e cronometradas."""
    if not scenes:
        return
    cols = 3 if len(scenes) >= 3 else max(1, len(scenes))
    rows = math.ceil(len(scenes) / cols)
    tile_w, tile_h = 380, 214
    caption_h = 48
    pad = 14
    header_h = 56

    canvas_w = pad + cols * (tile_w + pad)
    canvas_h = header_h + pad + rows * (tile_h + caption_h + pad)
    canvas = Image.new("RGB", (canvas_w, canvas_h), (11, 15, 25))
    draw = ImageDraw.Draw(canvas)

    f_head = _load_font(13, bold=True)
    f_title = _load_font(14, bold=False)
    f_badge = _load_font(12, bold=True)
    f_cap = _load_font(12, bold=False)
    f_sub = _load_font(11, bold=False)

    draw.rectangle([0, 0, canvas_w, header_h], fill=(19, 27, 46))
    clean_title = (title or "Vídeo")[:85]
    draw.text(
        (16, 10),
        f"VIDLENS AI  •  STORYBOARD CRONOMETRADO ({len(scenes)} CENAS)  •  {platform.upper()} ({duration_human})",
        fill=(56, 189, 248),
        font=f_head,
    )
    draw.text((16, 31), clean_title, fill=(241, 245, 249), font=f_title)

    for idx, sc in enumerate(scenes):
        r = idx // cols
        c = idx % cols
        x0 = pad + c * (tile_w + pad)
        y0 = header_h + pad + r * (tile_h + caption_h + pad)

        draw.rectangle(
            [x0, y0, x0 + tile_w, y0 + tile_h + caption_h],
            fill=(20, 29, 47),
            outline=(45, 58, 84),
        )
        fpath = scenes_dir / sc["filename"]
        if fpath.exists():
            try:
                with Image.open(fpath) as im:
                    im_rgb = im.convert("RGB")
                    im_rgb.thumbnail((tile_w, tile_h), Image.Resampling.LANCZOS)
                    ox = x0 + (tile_w - im_rgb.width) // 2
                    oy = y0 + (tile_h - im_rgb.height) // 2
                    canvas.paste(im_rgb, (ox, oy))
            except Exception:
                pass

        # Etiqueta de tempo no canto superior esquerdo do quadro
        badge_txt = f"Cena {sc['index']:02d} • {sc['time_range']}"
        draw.rectangle([x0 + 6, y0 + 6, x0 + 196, y0 + 27], fill=(9, 13, 22))
        draw.text((x0 + 11, y0 + 9), badge_txt, fill=(125, 211, 252), font=f_badge)

        # Trecho da fala logo abaixo da imagem
        spoken = sc.get("spoken_text") or "(sem fala neste trecho)"
        if len(spoken) > 52:
            spoken = spoken[:49] + "..."
        audio_lbl = sc.get("audio", {}).get("energy_label", "")
        draw.text((x0 + 8, y0 + tile_h + 6), spoken, fill=(226, 232, 240), font=f_cap)
        draw.text(
            (x0 + 8, y0 + tile_h + 26),
            f"Áudio: {audio_lbl} ({sc.get('audio', {}).get('rms_db', 0)} dB) | Nitidez: {sc['visual']['sharpness_score']}/100",
            fill=(148, 163, 184),
            font=f_sub,
        )

    canvas.save(out_path, "JPEG", quality=88, optimize=True)


def build_ai_markdown(pack: dict, base_url: str = "") -> str:
    """
    Constrói o relatório multimodal em Markdown estruturado para qualquer IA ler
    texto + imagens das cenas + espectrograma de áudio + linha do tempo completa.
    """
    b = base_url.rstrip("/")
    pid = pack["pack_id"]
    lines = [
        f"# [Pacote de Vídeo p/ IA] {pack['title']}",
        "",
        "## 1. Ficha Técnica e Fonte Original",
        f"- **Fonte Original:** {pack['source_url']}",
        f"- **Plataforma:** {pack['platform'].upper()} | **Autor/Canal:** {pack['uploader']}",
        f"- **Duração:** {pack['duration_human']} ({pack['duration_sec']}s) | **Resolução Capturada:** {pack['video_specs']['width']}x{pack['video_specs']['height']} ({pack['video_specs']['fps']} fps)",
        f"- **Fonte da Transcrição:** {pack['transcript']['source']}",
    ]
    if pack.get("description"):
        lines.append(f"- **Descrição / Notas para a IA:** {pack['description']}")
    if pack.get("video_url"):
        lines.append(f"- **Arquivo de Vídeo Preservado (.mp4):** {b}{pack['video_url']}")

    lines.extend(
        [
            "",
            "## 2. Visão Geral Visual (Storyboard Completo em 1 Imagem)",
            f"![Storyboard Completo de {pack['title']}]({b}/packs/{pid}/storyboard.jpg)",
            "",
            "## 3. Análise e Preservação de Áudio",
        ]
    )
    aud = pack.get("audio_telemetry") or {}
    if aud.get("available"):
        lines.extend(
            [
                f"- **Perfil Acústico:** {aud.get('profile_summary')}",
                f"- **Volume Médio (RMS):** {aud.get('rms_db')} dBFS | **Pico:** {aud.get('peak_db')} dBFS | **Faixa Dinâmica:** {aud.get('dynamic_range_db')} dB",
                f"- **Presença Sonora Ativa:** {aud.get('active_sound_pct')}% do tempo | **Energia na Faixa de Voz:** {aud.get('voice_band_energy_pct')}%",
                f"- **Áudio Original Preservado:** [Ouvir/Baixar MP3 Alta Qualidade]({b}/packs/{pid}/audio.mp3)",
                f"![Mapa Acústico e Espectrograma]({b}/packs/{pid}/spectrogram.png)",
            ]
        )
    else:
        lines.append("- Sem faixa de áudio detectada no vídeo.")

    lines.extend(["", "## 4. Linha do Tempo Multimodal Cena por Cena (Imagem + Descrição Visual + OCR + Áudio + Fala)"])
    for sc in pack.get("scenes", []):
        img_url = f"{b}/packs/{pid}/scenes/{sc['filename']}"
        vis = sc["visual"]
        aud_sc = sc.get("audio") or {}
        spoken = sc.get("spoken_text") or "_[Sem fala transcrita neste intervalo]_"
        v_desc = sc.get("visual_description") or "Quadro capturado da cena."
        ocr_txt = sc.get("ocr_text") or "Nenhum texto legível detectado na tela"
        motion_txt = sc.get("motion_summary") or "Quadro inicial de referência"
        lines.extend(
            [
                f"### Cena {sc['index']:02d} ({sc['time_range']})",
                f"![Cena {sc['index']:02d} em {sc['time_range']}]({img_url})",
                f"- **Descrição Visual (para IAs de texto):** {v_desc}",
                f"- **Movimento / Evolução em relação à cena anterior:** {motion_txt}",
                f"- **Texto Visível na Tela (OCR):** {ocr_txt}",
                f"- **Fala sincronizada no áudio:** {spoken}",
                f"- **Áudio no trecho:** {aud_sc.get('energy_label', '—')} ({aud_sc.get('rms_db', '—')} dBFS)",
                f"- **Telemetria de Imagem:** {vis['width']}x{vis['height']} | Nitidez {vis['sharpness_score']}/100 | Brilho {vis['brightness_pct']}% | Cores {', '.join(vis['dominant_colors'])}",
                "",
            ]
        )

    lines.extend(["## 5. Transcrição Completa Cronometrada"])
    segs = pack.get("transcript", {}).get("segments") or []
    if segs:
        for seg in segs:
            lines.append(f"- `[{format_duration(seg['start'])}]` {seg['text']}")
    else:
        lines.append("_Nenhuma fala detectada neste vídeo._")

    return "\n".join(lines)


def _compute_scene_motion(scenes: list[dict], scenes_dir: Path) -> None:
    """
    Calcula matematicamente a mudança visual (%) e direção predominante de deslocamento
    entre cenas consecutivas (útil para timelapses, nuvens, física e animações).
    """
    prev_gray = None
    for idx, sc in enumerate(scenes):
        fpath = scenes_dir / sc["filename"]
        if not fpath.exists():
            sc["motion_summary"] = "—"
            continue
        try:
            with Image.open(fpath) as im:
                gray = np.asarray(im.convert("L").resize((128, 72)), dtype=np.float32)
        except Exception:
            sc["motion_summary"] = "—"
            continue

        if prev_gray is None:
            sc["motion_summary"] = "Cena inicial (referência 0%)"
            prev_gray = gray
            continue

        diff_pct = round(float(np.mean(np.abs(gray - prev_gray)) / 255.0 * 100.0), 1)
        # Testa pequenos deslocamentos (-6..+6 px) para estimar direção aparente de movimento
        best_dx, best_dy, best_err = 0, 0, float("inf")
        core_prev = prev_gray[8:-8, 8:-8]
        for dy in (-4, -2, 0, 2, 4):
            for dx in (-6, -3, 0, 3, 6):
                shifted = gray[8 + dy : 72 - 8 + dy, 8 + dx : 128 - 8 + dx]
                err = float(np.mean(np.abs(shifted - core_prev)))
                if err < best_err:
                    best_err = err
                    best_dx, best_dy = dx, dy

        dirs = []
        if best_dx >= 3:
            dirs.append("esquerda → direita")
        elif best_dx <= -3:
            dirs.append("direita → esquerda")
        if best_dy >= 2:
            dirs.append("cima → baixo")
        elif best_dy <= -2:
            dirs.append("baixo → cima")

        if diff_pct < 3.5:
            label = f"Quase estático (variação {diff_pct}%)"
        elif diff_pct > 28.0:
            label = f"Corte de cena / grande transição visual ({diff_pct}%)"
        elif dirs:
            label = f"Variação visual de {diff_pct}% • Deslocamento aparente: {' / '.join(dirs)}"
        else:
            label = f"Evolução gradual no local (variação {diff_pct}%)"

        sc["motion_summary"] = label
        prev_gray = gray


def _fetch_real_youtube_duration_sec(vid_id: str) -> float | None:
    import httpx

    try:
        r = httpx.get(
            f"https://www.youtube.com/watch?v={vid_id}",
            headers={"User-Agent": "Mozilla/5.0", "Accept-Language": "en-US,en;q=0.9"},
            timeout=6.0,
        )
        m = re.search(r'"lengthSeconds"\s*:\s*"(\d+)"', r.text)
        if m:
            val = float(m.group(1))
            if val > 0:
                return val
    except Exception:
        pass
    return None


def _fallback_youtube_cloud_pack(pack_id: str, norm_url: str) -> dict | None:
    """
    Plano de contingência anti-bloqueio para servidores em nuvem compartilhada (ex: Render Free):
    Se o YouTube bloquear o download do fluxo .mp4 pelo IP do servidor, monta o pacote multimodal
    usando os 4 quadros oficiais do YouTube (hqdefault, hq1, hq2, hq3) + oEmbed + Transcrição nativa!
    """
    import httpx
    from urllib.parse import parse_qs, urlparse

    parsed = urlparse(norm_url)
    vid_id = (parse_qs(parsed.query).get("v") or [None])[0]
    if not vid_id:
        return None

    t0 = time.time()
    title = f"Vídeo YouTube ({vid_id})"
    uploader = "YouTube"
    try:
        oe = httpx.get(
            "https://www.youtube.com/oembed",
            params={"url": norm_url, "format": "json"},
            timeout=8.0,
        )
        if oe.status_code == 200:
            oed = oe.json()
            title = oed.get("title") or title
            uploader = oed.get("author_name") or uploader
    except Exception:
        pass

    transcript = extract_best_transcript(
        platform="youtube",
        video_id=vid_id,
        sub_files=[],
        audio_mp3_path=None,
        audio_wav_path=None,
        enable_local_whisper=False,
    )
    segs = transcript.get("segments") or []
    real_dur = _fetch_real_youtube_duration_sec(vid_id)
    est_dur = real_dur or (float(segs[-1]["end"]) if segs else 120.0)

    pack_dir = get_pack_dir(pack_id)
    if pack_dir.exists():
        shutil.rmtree(pack_dir, ignore_errors=True)
    scenes_dir = pack_dir / "scenes"
    scenes_dir.mkdir(parents=True, exist_ok=True)

    yt_frames = ["maxresdefault.jpg", "hq1.jpg", "hq2.jpg", "hq3.jpg"]
    scenes = []
    for idx, fname_yt in enumerate(yt_frames, start=1):
        try:
            r = httpx.get(f"https://i.ytimg.com/vi/{vid_id}/{fname_yt}", timeout=8.0)
            if (r.status_code != 200 or len(r.content) < 400) and fname_yt == "maxresdefault.jpg":
                r = httpx.get(f"https://i.ytimg.com/vi/{vid_id}/hqdefault.jpg", timeout=8.0)
            if r.status_code != 200 or len(r.content) < 400:
                continue
            out_name = f"scene_{len(scenes)+1:02d}.jpg"
            out_path = scenes_dir / out_name
            out_path.write_bytes(r.content)
            s_start = round((idx - 1) * (est_dur / 4.0), 2)
            s_end = round(idx * (est_dur / 4.0), 2)
            metrics = _compute_frame_metrics(out_path)
            scenes.append(
                {
                    "index": len(scenes) + 1,
                    "start_sec": s_start,
                    "end_sec": s_end,
                    "time_range": f"{format_duration(s_start)} – {format_duration(s_end)}",
                    "filename": out_name,
                    "image_url": f"/packs/{pack_id}/scenes/{out_name}",
                    "visual": metrics,
                    "audio": {"rms_db": "—", "energy_label": "Extraído via Modo Rápido Nuvem"},
                }
            )
        except Exception:
            continue

    if not scenes:
        return None

    _align_transcript_to_scenes(scenes, segs)
    storyboard_path = pack_dir / "storyboard.jpg"
    _render_storyboard(
        scenes=scenes,
        scenes_dir=scenes_dir,
        out_path=storyboard_path,
        title=title,
        platform="youtube",
        duration_human=format_duration(est_dur),
    )

    _compute_scene_motion(scenes, scenes_dir)
    settings = get_settings()
    vision_source = enrich_scenes_with_vision_and_ocr(
        scenes=scenes,
        scenes_dir=scenes_dir,
        storyboard_path=storyboard_path,
        groq_api_key=settings.get("groq_api_key", ""),
        gemini_api_key=settings.get("gemini_api_key", ""),
    )

    pack_data = {
        "pack_id": pack_id,
        "title": title,
        "source_url": norm_url,
        "platform": "youtube",
        "uploader": uploader,
        "description": "Extraído via Modo Instantâneo Anti-Bloqueio (Quadros Oficiais + OCR + Visão + Transcrição).",
        "duration_sec": round(est_dur, 1),
        "duration_human": format_duration(est_dur),
        "created_at": round(time.time(), 2),
        "processing_time_sec": round(time.time() - t0, 2),
        "vision_source": vision_source,
        "video_specs": {
            "width": scenes[0]["visual"]["width"],
            "height": scenes[0]["visual"]["height"],
            "fps": 30.0,
            "video_codec": "yt-frames",
            "audio_codec": "transcript",
        },
        "cover_image": scenes[0]["image_url"],
        "storyboard_url": f"/packs/{pack_id}/storyboard.jpg",
        "spectrogram_url": None,
        "audio_url": None,
        "reader_url": f"/r/{pack_id}",
        "audio_telemetry": {
            "available": False,
            "profile_summary": "Modo Anti-Bloqueio Nuvem: Fala completa preservada via legenda oficial",
        },
        "transcript": transcript,
        "scenes": scenes,
    }
    (pack_dir / "ai_report.md").write_text(
        build_ai_markdown(pack_data, base_url=""), encoding="utf-8"
    )
    return save_pack(pack_id, pack_data)


def fast_convert_for_ai_search(url: str) -> dict | None:
    """
    Conversão ultrarrápida (< 2s) usada pelo endpoint /ai/search para nunca estourar
    o limite de tempo (timeout de ~10s) dos agentes web do Claude, ChatGPT e Perplexity.
    """
    norm_url = normalize_video_url(url)
    if not norm_url:
        return None
    pack_id = make_pack_id(norm_url)
    cached = load_pack(pack_id)
    if cached:
        return cached
    if detect_platform(norm_url) == "youtube":
        return _fallback_youtube_cloud_pack(pack_id, norm_url)
    return None


def process_video_from_url(
    url: str, max_scenes: int | None = None, force_refresh: bool = False
) -> dict:
    """Converte um link de vídeo em um Pacote Multimodal Legível por IA (com cache)."""
    norm_url = normalize_video_url(url)
    if not norm_url or not norm_url.startswith("http"):
        raise VideoConversionError("Informe um link válido começando com http:// ou https://")

    pack_id = make_pack_id(norm_url)
    if not force_refresh:
        cached = load_pack(pack_id)
        if cached:
            return cached

    settings = get_settings()
    n_scenes = max(4, min(16, int(max_scenes or settings.get("default_max_scenes", 8))))

    with tempfile.TemporaryDirectory() as tmp:
        tmp_dir = Path(tmp)
        try:
            video_file, ydl_info, sub_files = _download_video_with_ytdlp(norm_url, tmp_dir)
        except VideoConversionError:
            if detect_platform(norm_url) == "youtube":
                fb = _fallback_youtube_cloud_pack(pack_id, norm_url)
                if fb:
                    return fb
            raise

        plat = detect_platform(norm_url)
        title = ydl_info.get("title") or f"Vídeo {plat.capitalize()}"
        uploader = (
            ydl_info.get("uploader")
            or ydl_info.get("channel")
            or ydl_info.get("creator")
            or plat.capitalize()
        )
        vid_id = ydl_info.get("id")
        desc = (ydl_info.get("description") or "").strip()[:500]
        duration_meta = ydl_info.get("duration")

        return _build_pack_from_local_video(
            pack_id=pack_id,
            video_file=video_file,
            source_url=norm_url,
            platform=plat,
            title=title,
            uploader=uploader,
            video_id=vid_id,
            description=desc,
            duration_override=duration_meta,
            sub_files=sub_files,
            max_scenes=n_scenes,
            settings=settings,
        )


def process_uploaded_video(
    file_path: Path,
    original_filename: str,
    max_scenes: int | None = None,
    custom_title: str = "",
    author_name: str = "",
    notes_for_ai: str = "",
) -> dict:
    """Converte e salva um vídeo enviado pelo usuário (com link permanente para IAs!)."""
    settings = get_settings()
    n_scenes = max(4, min(24, int(max_scenes or settings.get("default_max_scenes", 8))))
    unique_key = f"upload://{original_filename}:{file_path.stat().st_size}:{int(time.time())}"
    pack_id = make_pack_id(unique_key)
    clean_title = (
        custom_title.strip()
        or Path(original_filename).stem.replace("_", " ").replace("-", " ").strip()
        or "Vídeo Adicionado"
    )
    uploader = author_name.strip() or "Vídeo Adicionado no Site"
    desc = (
        notes_for_ai.strip()
        or f"Vídeo adicionado diretamente ({original_filename}) para leitura multimodal por IA."
    )

    return _build_pack_from_local_video(
        pack_id=pack_id,
        video_file=file_path,
        source_url=f"Vídeo hospedado neste site ({original_filename})",
        platform="upload",
        title=clean_title,
        uploader=uploader,
        video_id=None,
        description=desc,
        duration_override=None,
        sub_files=[],
        max_scenes=n_scenes,
        settings=settings,
        keep_video_copy=True,
        permanent_save=True,
    )


def _build_pack_from_local_video(
    pack_id: str,
    video_file: Path,
    source_url: str,
    platform: str,
    title: str,
    uploader: str,
    video_id: str | None,
    description: str,
    duration_override: float | None,
    sub_files: list[Path],
    max_scenes: int,
    settings: dict,
    keep_video_copy: bool = False,
    permanent_save: bool = False,
) -> dict:
    t0 = time.time()
    pack_dir = get_pack_dir(pack_id)
    if pack_dir.exists():
        shutil.rmtree(pack_dir, ignore_errors=True)
    pack_dir.mkdir(parents=True, exist_ok=True)
    scenes_dir = pack_dir / "scenes"

    specs = _probe_video_duration_and_info(video_file)
    duration = float(duration_override or specs["duration"] or 0.0)
    if duration <= 0 and specs["duration"] > 0:
        duration = specs["duration"]

    # 1. Cenas visuais em alta qualidade
    scenes = _extract_scene_keyframes(video_file, duration, scenes_dir, max_scenes=max_scenes)
    if not scenes:
        raise VideoConversionError("Não foi possível extrair quadros visuais deste vídeo.")

    # 2. Áudio preservado + Telemetria acústica + Espectrograma
    has_audio = specs.get("audio_codec") != "none"
    audio_telemetry, mp3_path, wav_path = _extract_and_analyze_audio(
        video_file, pack_dir, scenes, has_audio=has_audio
    )

    # 3. Transcrição de fala (3 camadas gratuitas)
    transcript = extract_best_transcript(
        platform=platform,
        video_id=video_id,
        sub_files=sub_files,
        audio_mp3_path=mp3_path,
        audio_wav_path=wav_path,
        groq_api_key=settings.get("groq_api_key", ""),
        enable_local_whisper=settings.get("enable_local_whisper", True),
    )

    # Remove WAV temporário pesado após transcrição e análise
    if wav_path and wav_path.exists():
        try:
            wav_path.unlink()
        except Exception:
            pass

    # 4. Alinha transcrição com cada cena, mede movimento e renderiza o Storyboard único HD
    _align_transcript_to_scenes(scenes, transcript.get("segments") or [])
    _compute_scene_motion(scenes, scenes_dir)
    storyboard_path = pack_dir / "storyboard.jpg"
    _render_storyboard(
        scenes=scenes,
        scenes_dir=scenes_dir,
        out_path=storyboard_path,
        title=title,
        platform=platform,
        duration_human=format_duration(duration),
    )

    # Se for upload direto e tiver até 20 MB, preserva também uma cópia web do vídeo original (.mp4)
    saved_video_url = None
    if keep_video_copy and video_file.exists() and video_file.stat().st_size <= 20 * 1024 * 1024:
        dest_vid = pack_dir / "video.mp4"
        try:
            shutil.copy2(video_file, dest_vid)
            saved_video_url = f"/packs/{pack_id}/video.mp4"
        except Exception:
            saved_video_url = None

    # 5. Descrição Visual Textual + OCR de texto na tela (para IAs como Claude/Perplexity lerem via texto!)
    vision_source = enrich_scenes_with_vision_and_ocr(
        scenes=scenes,
        scenes_dir=scenes_dir,
        storyboard_path=storyboard_path,
        groq_api_key=settings.get("groq_api_key", ""),
        gemini_api_key=settings.get("gemini_api_key", ""),
    )

    # URLs relativas limpas (funcionam em qualquer domínio/preview)
    for sc in scenes:
        sc["image_url"] = f"/packs/{pack_id}/scenes/{sc['filename']}"

    pack_data = {
        "pack_id": pack_id,
        "title": title,
        "source_url": saved_video_url or source_url,
        "platform": platform,
        "uploader": uploader,
        "description": description,
        "duration_sec": round(duration, 1),
        "duration_human": format_duration(duration),
        "created_at": round(time.time(), 2),
        "processing_time_sec": round(time.time() - t0, 2),
        "vision_source": vision_source,
        "video_specs": specs,
        "cover_image": scenes[0]["image_url"] if scenes else f"/packs/{pack_id}/storyboard.jpg",
        "storyboard_url": f"/packs/{pack_id}/storyboard.jpg",
        "spectrogram_url": f"/packs/{pack_id}/spectrogram.png" if audio_telemetry.get("available") else None,
        "audio_url": f"/packs/{pack_id}/audio.mp3" if (mp3_path and mp3_path.exists()) else None,
        "video_url": saved_video_url,
        "reader_url": f"/r/{pack_id}",
        "audio_telemetry": audio_telemetry,
        "transcript": transcript,
        "scenes": scenes,
    }

    # Salva também o arquivo Markdown estático dentro do pacote (para exportação .zip)
    md_text = build_ai_markdown(pack_data, base_url="")
    (pack_dir / "ai_report.md").write_text(md_text, encoding="utf-8")

    return save_pack(pack_id, pack_data, permanent=permanent_save)
