import base64
import json
import os
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import httpx

DEFAULT_GITHUB_REPO = "rodrihoenzo-arch/Sourcefont.AI"
VAULT_BRANCH = "saved-packs"


def get_vault_config(settings: dict) -> tuple[str, str]:
    token = (
        os.environ.get("GITHUB_TOKEN")
        or settings.get("github_token")
        or ""
    ).strip()
    repo = (
        os.environ.get("GITHUB_REPO")
        or settings.get("github_repo")
        or DEFAULT_GITHUB_REPO
    ).strip()
    return token, repo


def _gh_headers(token: str) -> dict:
    h = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if token:
        h["Authorization"] = f"Bearer {token}"
    return h


def _ensure_vault_branch(client: httpx.Client, repo: str, token: str) -> str | None:
    """Garante que a branch 'saved-packs' exista (sem disparar redeploy da 'main' no Render) e retorna o SHA."""
    headers = _gh_headers(token)
    r = client.get(f"https://api.github.com/repos/{repo}/git/ref/heads/{VAULT_BRANCH}", headers=headers)
    if r.status_code == 200:
        return r.json()["object"]["sha"]

    # Cria a partir do commit atual da main
    r_main = client.get(f"https://api.github.com/repos/{repo}/git/ref/heads/main", headers=headers)
    if r_main.status_code != 200:
        return None
    main_sha = r_main.json()["object"]["sha"]
    r_create = client.post(
        f"https://api.github.com/repos/{repo}/git/refs",
        headers=headers,
        json={"ref": f"refs/heads/{VAULT_BRANCH}", "sha": main_sha},
    )
    if r_create.status_code in (200, 201):
        return main_sha
    return None


def backup_pack_to_github(pack_id: str, pack_dir: Path, pack_data: dict, settings: dict) -> bool:
    """
    Salva permanentemente o pacote convertido na branch 'saved-packs' do GitHub em 1 único commit atômico.
    Assim, mesmo quando o plano gratuito do Render dorme e limpa o disco, o link nunca morre!
    """
    token, repo = get_vault_config(settings)
    if not token or not repo or not pack_dir.exists():
        return False

    try:
        headers = _gh_headers(token)
        with httpx.Client(timeout=35.0) as client:
            head_sha = _ensure_vault_branch(client, repo, token)
            if not head_sha:
                return False

            r_commit = client.get(
                f"https://api.github.com/repos/{repo}/git/commits/{head_sha}",
                headers=headers,
            )
            if r_commit.status_code != 200:
                return False
            base_tree_sha = r_commit.json()["tree"]["sha"]

            # Coleta todos os arquivos do pacote (até 22 MB por arquivo para respeitar limite da API)
            files_to_push: list[tuple[str, bytes]] = []
            for p in sorted(pack_dir.rglob("*")):
                if p.is_file() and not p.name.startswith("_temp"):
                    sz = p.stat().st_size
                    if sz <= 22 * 1024 * 1024:
                        rel = p.relative_to(pack_dir).as_posix()
                        files_to_push.append((f"packs/{pack_id}/{rel}", p.read_bytes()))

            # Atualiza também o índice geral (packs/index.json) na branch saved-packs
            idx_map = {}
            r_idx = client.get(
                f"https://raw.githubusercontent.com/{repo}/{VAULT_BRANCH}/packs/index.json",
                headers=headers,
            )
            if r_idx.status_code == 200:
                try:
                    for item in r_idx.json():
                        if item.get("pack_id"):
                            idx_map[item["pack_id"]] = item
                except Exception:
                    pass

            idx_map[pack_id] = {
                "pack_id": pack_id,
                "title": pack_data.get("title"),
                "platform": pack_data.get("platform"),
                "uploader": pack_data.get("uploader"),
                "duration_sec": pack_data.get("duration_sec"),
                "duration_human": pack_data.get("duration_human"),
                "source_url": pack_data.get("source_url"),
                "created_at": pack_data.get("created_at", 0),
                "scenes_count": len(pack_data.get("scenes", [])),
                "transcript_source": pack_data.get("transcript", {}).get("source"),
                "thumbnail_url": pack_data.get("cover_image"),
                "storyboard_url": pack_data.get("storyboard_url"),
                "audio_url": pack_data.get("audio_url"),
                "video_url": pack_data.get("video_url"),
                "permanent": True,
            }
            sorted_idx = sorted(idx_map.values(), key=lambda x: x.get("created_at", 0), reverse=True)
            files_to_push.append(
                ("packs/index.json", json.dumps(sorted_idx, ensure_ascii=False, indent=2).encode("utf-8"))
            )

            # Cria blobs na API do GitHub
            tree_items = []
            for git_path, raw_bytes in files_to_push:
                b64 = base64.b64encode(raw_bytes).decode("ascii")
                rb = client.post(
                    f"https://api.github.com/repos/{repo}/git/blobs",
                    headers=headers,
                    json={"content": b64, "encoding": "base64"},
                )
                if rb.status_code not in (200, 201):
                    continue
                blob_sha = rb.json()["sha"]
                tree_items.append(
                    {
                        "path": git_path,
                        "mode": "100644",
                        "type": "blob",
                        "sha": blob_sha,
                    }
                )

            if not tree_items:
                return False

            rt = client.post(
                f"https://api.github.com/repos/{repo}/git/trees",
                headers=headers,
                json={"base_tree": base_tree_sha, "tree": tree_items},
            )
            if rt.status_code not in (200, 201):
                return False
            new_tree_sha = rt.json()["sha"]

            rc = client.post(
                f"https://api.github.com/repos/{repo}/git/commits",
                headers=headers,
                json={
                    "message": f"Save video pack {pack_id}: {(pack_data.get('title') or '')[:50]}",
                    "tree": new_tree_sha,
                    "parents": [head_sha],
                },
            )
            if rc.status_code not in (200, 201):
                return False
            new_commit_sha = rc.json()["sha"]

            ru = client.patch(
                f"https://api.github.com/repos/{repo}/git/refs/heads/{VAULT_BRANCH}",
                headers=headers,
                json={"sha": new_commit_sha, "force": True},
            )
            return ru.status_code == 200
    except Exception:
        return False


def restore_pack_from_github(pack_id: str, pack_dir: Path, settings: dict) -> dict | None:
    """
    Se o Render dormiu e limpou o disco local, restaura automaticamente o pacote
    (JSON + Storyboard + Cenas + Áudio + Vídeo) da branch 'saved-packs' em < 1s!
    """
    token, repo = get_vault_config(settings)
    if not repo:
        return None

    headers = _gh_headers(token) if token else {}
    base_raw = f"https://raw.githubusercontent.com/{repo}/{VAULT_BRANCH}/packs/{pack_id}"
    try:
        with httpx.Client(timeout=15.0) as client:
            r_meta = client.get(f"{base_raw}/pack.json", headers=headers)
            if r_meta.status_code != 200:
                return None
            pack_data = r_meta.json()

            pack_dir.mkdir(parents=True, exist_ok=True)
            scenes_dir = pack_dir / "scenes"
            scenes_dir.mkdir(parents=True, exist_ok=True)

            (pack_dir / "pack.json").write_text(
                json.dumps(pack_data, ensure_ascii=False, indent=2), encoding="utf-8"
            )

            # Baixa todos os ativos em paralelo para restaurar o pacote completo no disco local
            rel_files = ["storyboard.jpg", "ai_report.md"]
            if pack_data.get("spectrogram_url"):
                rel_files.append("spectrogram.png")
            if pack_data.get("audio_url"):
                rel_files.append("audio.mp3")
            if pack_data.get("video_url"):
                rel_files.append("video.mp4")
            for sc in pack_data.get("scenes") or []:
                if sc.get("filename"):
                    rel_files.append(f"scenes/{sc['filename']}")

            def _fetch_one(rel_path: str):
                try:
                    rr = client.get(f"{base_raw}/{rel_path}", headers=headers)
                    if rr.status_code == 200 and rr.content:
                        out = pack_dir / rel_path
                        out.parent.mkdir(parents=True, exist_ok=True)
                        out.write_bytes(rr.content)
                except Exception:
                    pass

            with ThreadPoolExecutor(max_workers=6) as pool:
                list(pool.map(_fetch_one, rel_files))

            return pack_data
    except Exception:
        return None


def list_vault_packs(settings: dict) -> list[dict]:
    """Lê a lista de vídeos permanentes salvos na branch 'saved-packs'."""
    token, repo = get_vault_config(settings)
    if not repo:
        return []
    headers = _gh_headers(token) if token else {}
    try:
        r = httpx.get(
            f"https://raw.githubusercontent.com/{repo}/{VAULT_BRANCH}/packs/index.json",
            headers=headers,
            timeout=6.0,
        )
        if r.status_code == 200:
            data = r.json()
            if isinstance(data, list):
                return data
    except Exception:
        pass
    return []
