import html
import os
import shutil
import tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from .search_engine import format_duration, search_videos
from .storage import (
    BASE_DIR,
    PACKS_DIR,
    build_pack_zip_bytes,
    delete_pack,
    get_settings,
    list_packs,
    load_dossier,
    load_pack,
    save_dossier,
    update_settings,
)
from .video_processor import (
    VideoConversionError,
    build_ai_markdown,
    process_uploaded_video,
    process_video_from_url,
)

app = FastAPI(
    title="VidLens AI — Motor de Busca e Leitura de Vídeos para IAs",
    description=(
        "Pesquisa vídeos no YouTube, TikTok e Web e os converte em pacotes multimodais "
        "(cenas em imagem HD, storyboard, áudio preservado, espectrograma e transcrição sincronizada) "
        "que qualquer Inteligência Artificial consegue ler e enxergar."
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

STATIC_DIR = BASE_DIR / "static"
STATIC_DIR.mkdir(parents=True, exist_ok=True)
PACKS_DIR.mkdir(parents=True, exist_ok=True)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.mount("/packs", StaticFiles(directory=str(PACKS_DIR)), name="packs")

_SEARCH_EXECUTOR = ThreadPoolExecutor(max_workers=4)
_EXECUTOR = ThreadPoolExecutor(max_workers=int(os.environ.get("MAX_WORKERS", "2")))


def get_public_base_url(request: Request) -> str:
    proto = request.headers.get("x-forwarded-proto") or request.url.scheme or "http"
    host = (
        request.headers.get("x-forwarded-host")
        or request.headers.get("host")
        or request.url.netloc
    )
    # Em ambientes cloud (hf.space, e2b.app, onrender.com), força https
    if any(d in host for d in (".hf.space", ".e2b.app", ".onrender.com", ".railway.app")):
        proto = "https"
    return f"{proto}://{host}".rstrip("/")


def _wants_markdown(request: Request, fmt: str | None) -> bool:
    if fmt and fmt.lower() in ("md", "markdown", "text", "raw"):
        return True
    accept = (request.headers.get("accept") or "").lower()
    return "text/markdown" in accept


def _render_pack_semantic_html(pack: dict, base_url: str) -> str:
    """
    Renderiza HTML semântico limpo, 100% no servidor (sem depender de JS),
    para que ferramentas como fetch_page, Perplexity, ChatGPT, Claude e buscadores
    leiam todas as falas, telemetria acústica e vejam as imagens das cenas.
    """
    pid = pack["pack_id"]
    esc = html.escape
    title = esc(pack.get("title") or "Vídeo")
    plat = esc((pack.get("platform") or "web").upper())
    uploader = esc(pack.get("uploader") or "Autor")
    src_url = esc(pack.get("source_url") or "")
    dur = esc(pack.get("duration_human") or "—")
    t_src = esc(pack.get("transcript", {}).get("source") or "—")
    aud = pack.get("audio_telemetry") or {}
    specs = pack.get("video_specs") or {}

    scenes_html = []
    for sc in pack.get("scenes", []):
        idx = sc["index"]
        tr = esc(sc["time_range"])
        img_abs = f"{base_url}/packs/{pid}/scenes/{sc['filename']}"
        spoken = esc(sc.get("spoken_text") or "[Sem fala transcrita neste intervalo]")
        aud_sc = sc.get("audio") or {}
        vis = sc.get("visual") or {}
        scenes_html.append(
            f"""
            <article class="scene">
              <h3>Cena {idx:02d} — Tempo {tr}</h3>
              <img src="{img_abs}" alt="Cena {idx:02d} ({tr}) de {title}" loading="eager" />
              <ul>
                <li><strong>Fala sincronizada:</strong> {spoken}</li>
                <li><strong>Áudio neste trecho:</strong> {esc(str(aud_sc.get('energy_label', '—')))} ({aud_sc.get('rms_db', '—')} dBFS)</li>
                <li><strong>Qualidade Visual:</strong> {vis.get('width', 0)}x{vis.get('height', 0)} px | Nitidez {vis.get('sharpness_score', 0)}/100 | Brilho {vis.get('brightness_pct', 0)}% | Cores {', '.join(vis.get('dominant_colors', []))}</li>
              </ul>
            </article>
            """
        )

    segs = pack.get("transcript", {}).get("segments") or []
    if segs:
        transcript_items = "\n".join(
            f"<li><code>[{format_duration(s['start'])}]</code> {esc(s['text'])}</li>"
            for s in segs
        )
        transcript_block = f"<ul>{transcript_items}</ul>"
    else:
        transcript_block = "<p><em>Nenhuma fala verbal detectada neste vídeo.</em></p>"

    audio_block = ""
    if aud.get("available"):
        audio_abs = f"{base_url}/packs/{pid}/audio.mp3"
        spec_abs = f"{base_url}/packs/{pid}/spectrogram.png"
        audio_block = f"""
        <section>
          <h2>3. Preservação e Análise Acústica do Áudio</h2>
          <ul>
            <li><strong>Resumo Acústico:</strong> {esc(str(aud.get('profile_summary', '')))}</li>
            <li><strong>Volume Médio (RMS):</strong> {aud.get('rms_db')} dBFS | <strong>Pico:</strong> {aud.get('peak_db')} dBFS | <strong>Dinâmica:</strong> {aud.get('dynamic_range_db')} dB</li>
            <li><strong>Atividade Sonora:</strong> {aud.get('active_sound_pct')}% do vídeo | <strong>Energia Vocal (250–3600 Hz):</strong> {aud.get('voice_band_energy_pct')}%</li>
            <li><strong>Arquivo de Áudio Preservado:</strong> <a href="{audio_abs}">{audio_abs}</a></li>
          </ul>
          <audio controls src="{audio_abs}" style="width:100%;max-width:640px;margin:8px 0;"></audio>
          <div>
            <img src="{spec_abs}" alt="Mapa Acústico: Forma de Onda e Espectrograma de {title}" style="max-width:100%;border-radius:8px;" />
          </div>
        </section>
        """

    storyboard_abs = f"{base_url}/packs/{pid}/storyboard.jpg"
    md_url = f"{base_url}/r/{pid}?format=md"

    return f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>[VidLens AI] {title}</title>
  <style>
    body {{ font-family: system-ui, -apple-system, sans-serif; background:#0b0f19; color:#e2e8f0; max-width:980px; margin:0 auto; padding:24px; line-height:1.6; }}
    a {{ color:#38bdf8; }}
    .topbar {{ display:flex; flex-wrap:wrap; gap:12px; justify-content:space-between; align-items:center; background:#131b2e; padding:12px 16px; border-radius:10px; border:1px solid #1e293b; margin-bottom:20px; }}
    h1 {{ font-size:1.55rem; margin:0 0 8px; color:#f8fafc; }}
    h2 {{ font-size:1.2rem; color:#7dd3fc; border-bottom:1px solid #1e293b; padding-bottom:6px; margin-top:28px; }}
    .meta {{ background:#111827; padding:14px 18px; border-radius:10px; border:1px solid #1f2937; }}
    .scene {{ background:#131b2e; border:1px solid #1e293b; border-radius:12px; padding:16px; margin:16px 0; }}
    .scene img {{ max-width:100%; height:auto; border-radius:8px; border:1px solid #334155; display:block; margin:10px 0; }}
    code {{ background:#1e293b; padding:2px 6px; border-radius:4px; color:#bae6fd; }}
    .btn {{ background:#0284c7; color:#fff; text-decoration:none; padding:6px 12px; border-radius:6px; font-size:0.9rem; font-weight:600; }}
  </style>
</head>
<body>
  <div class="topbar">
    <div><strong>VidLens AI</strong> • Página Multimodal Otimizada para Leitura por IA</div>
    <div style="display:flex;gap:8px;">
      <a class="btn" href="/">Abrir Painel VidLens</a>
      <a class="btn" style="background:#334155;" href="{md_url}">Ver em Markdown Puro</a>
    </div>
  </div>

  <h1>{title}</h1>
  <section class="meta">
    <h2>1. Metadados e Fonte Original</h2>
    <ul>
      <li><strong>Link Original:</strong> <a href="{src_url}">{src_url}</a></li>
      <li><strong>Plataforma:</strong> {plat} | <strong>Canal/Criador:</strong> {uploader}</li>
      <li><strong>Duração:</strong> {dur} ({pack.get('duration_sec')}s) | <strong>Vídeo:</strong> {specs.get('width', 0)}x{specs.get('height', 0)} ({specs.get('fps', 0)} fps)</li>
      <li><strong>Método de Transcrição:</strong> {t_src}</li>
    </ul>
  </section>

  <section>
    <h2>2. Storyboard Completo (Visão Geral do Vídeo em 1 Imagem)</h2>
    <p>Grade cronometrada com todas as cenas detectadas e falas correspondentes:</p>
    <img src="{storyboard_abs}" alt="Storyboard completo de {title}" style="max-width:100%;border-radius:10px;border:1px solid #334155;" />
  </section>

  {audio_block}

  <section>
    <h2>4. Linha do Tempo Cena por Cena (Quadros HD + Fala + Áudio)</h2>
    {''.join(scenes_html)}
  </section>

  <section>
    <h2>5. Transcrição Completa Sincronizada</h2>
    {transcript_block}
  </section>
</body>
</html>"""


class ConvertRequest(BaseModel):
    url: str
    max_scenes: int = 8
    force_refresh: bool = False


class BatchResearchRequest(BaseModel):
    query: str
    platform: str = "all"
    top_n: int = 2
    max_scenes: int = 6


class SettingsRequest(BaseModel):
    groq_api_key: str | None = None
    default_max_scenes: int | None = None
    enable_local_whisper: bool | None = None


@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def home():
    index_file = STATIC_DIR / "index.html"
    return HTMLResponse(index_file.read_text(encoding="utf-8"))


@app.get("/api/health")
async def health():
    settings = get_settings()
    return {
        "status": "ok",
        "engine": "VidLens AI v1.0",
        "ffmpeg": shutil.which("ffmpeg") is not None,
        "node_js": shutil.which("node") is not None,
        "groq_configured": bool(settings.get("groq_api_key")),
        "local_whisper_enabled": bool(settings.get("enable_local_whisper", True)),
        "cached_packs": len(list_packs(200)),
    }


@app.get("/api/settings")
async def api_get_settings():
    s = get_settings()
    key = s.get("groq_api_key") or ""
    masked = f"***{key[-4:]}" if len(key) > 6 else ("" if not key else "***")
    return {
        "has_groq_key": bool(key),
        "groq_api_key_masked": masked,
        "default_max_scenes": s.get("default_max_scenes", 8),
        "enable_local_whisper": s.get("enable_local_whisper", True),
    }


@app.post("/api/settings")
async def api_save_settings(req: SettingsRequest):
    payload = {k: v for k, v in req.model_dump().items() if v is not None}
    updated = update_settings(payload)
    key = updated.get("groq_api_key") or ""
    return {
        "ok": True,
        "has_groq_key": bool(key),
        "default_max_scenes": updated.get("default_max_scenes", 8),
        "enable_local_whisper": updated.get("enable_local_whisper", True),
    }


@app.get("/api/search")
async def api_search(
    request: Request,
    q: str = Query(..., description="Tema ou pergunta para pesquisar vídeos"),
    platform: str = Query("all", description="all, youtube, tiktok ou instagram"),
    max_results: int = Query(8, ge=1, le=16),
):
    import asyncio

    loop = asyncio.get_running_loop()
    results = await loop.run_in_executor(
        _SEARCH_EXECUTOR, search_videos, q, platform, max_results
    )
    base = get_public_base_url(request)
    for r in results:
        r["ai_convert_url"] = f"{base}/ai?url={r['url']}"
        if r.get("cached"):
            r["reader_url"] = f"{base}/r/{r['pack_id']}"
    return {"query": q, "platform": platform, "count": len(results), "results": results}


@app.post("/api/convert")
async def api_convert(req: ConvertRequest, request: Request):
    import asyncio

    loop = asyncio.get_running_loop()
    try:
        pack = await loop.run_in_executor(
            _EXECUTOR,
            process_video_from_url,
            req.url,
            req.max_scenes,
            req.force_refresh,
        )
    except VideoConversionError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro inesperado na conversão: {e}")

    base = get_public_base_url(request)
    pack_out = dict(pack)
    pack_out["ai_markdown"] = build_ai_markdown(pack, base_url=base)
    pack_out["public_reader_url"] = f"{base}/r/{pack['pack_id']}"
    return pack_out


@app.post("/api/upload")
async def api_upload(
    request: Request,
    file: UploadFile = File(...),
    max_scenes: int = Form(8),
):
    import asyncio

    allowed = {".mp4", ".mov", ".webm", ".mkv", ".m4v", ".avi"}
    ext = Path(file.filename or "video.mp4").suffix.lower()
    if ext not in allowed:
        raise HTTPException(
            status_code=400,
            detail=f"Formato {ext} não suportado. Envie um vídeo .mp4, .mov, .webm ou .mkv.",
        )

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp) / f"upload{ext}"
        with open(tmp_path, "wb") as out_f:
            shutil.copyfileobj(file.file, out_f)
        if tmp_path.stat().st_size > 180 * 1024 * 1024:
            raise HTTPException(status_code=400, detail="O arquivo excede o limite de 180 MB.")

        loop = asyncio.get_running_loop()
        try:
            pack = await loop.run_in_executor(
                _EXECUTOR,
                process_uploaded_video,
                tmp_path,
                file.filename or "video.mp4",
                max_scenes,
            )
        except VideoConversionError as e:
            raise HTTPException(status_code=400, detail=str(e))

    base = get_public_base_url(request)
    pack_out = dict(pack)
    pack_out["ai_markdown"] = build_ai_markdown(pack, base_url=base)
    pack_out["public_reader_url"] = f"{base}/r/{pack['pack_id']}"
    return pack_out


@app.post("/api/research-batch")
async def api_research_batch(req: BatchResearchRequest, request: Request):
    """Pesquisa um assunto e converte automaticamente os principais vídeos em um Dossiê para IA."""
    import asyncio

    loop = asyncio.get_running_loop()
    found = await loop.run_in_executor(
        _EXECUTOR, search_videos, req.query, req.platform, max(req.top_n + 3, 6)
    )
    if not found:
        raise HTTPException(status_code=404, detail="Nenhum vídeo encontrado para este tema.")

    converted_packs = []
    errors = []
    top_n = max(1, min(4, req.top_n))
    for candidate in found:
        if len(converted_packs) >= top_n:
            break
        try:
            p = await loop.run_in_executor(
                _EXECUTOR,
                process_video_from_url,
                candidate["url"],
                req.max_scenes,
                False,
            )
            converted_packs.append(p)
        except Exception as e:
            errors.append({"url": candidate["url"], "error": str(e)})

    if not converted_packs:
        raise HTTPException(
            status_code=400,
            detail="Os vídeos encontrados bloquearam o download automático. Tente converter outro resultado da lista.",
        )

    dossier = save_dossier(
        query=req.query,
        pack_ids=[p["pack_id"] for p in converted_packs],
        platform=req.platform,
    )
    base = get_public_base_url(request)
    return {
        "dossier_id": dossier["dossier_id"],
        "query": req.query,
        "dossier_url": f"{base}/d/{dossier['dossier_id']}",
        "dossier_markdown_url": f"{base}/d/{dossier['dossier_id']}?format=md",
        "packs": converted_packs,
        "skipped_errors": errors,
    }


@app.get("/api/packs")
async def api_list_packs(request: Request):
    base = get_public_base_url(request)
    items = list_packs(60)
    for it in items:
        it["public_reader_url"] = f"{base}/r/{it['pack_id']}"
    return {"packs": items}


@app.get("/api/packs/{pack_id}")
async def api_get_pack(pack_id: str, request: Request):
    pack = load_pack(pack_id)
    if not pack:
        raise HTTPException(status_code=404, detail="Pacote de vídeo não encontrado.")
    base = get_public_base_url(request)
    out = dict(pack)
    out["ai_markdown"] = build_ai_markdown(pack, base_url=base)
    out["public_reader_url"] = f"{base}/r/{pack_id}"
    return out


@app.delete("/api/packs/{pack_id}")
async def api_delete_pack(pack_id: str):
    ok = delete_pack(pack_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Pacote não encontrado.")
    return {"deleted": True, "pack_id": pack_id}


@app.get("/api/packs/{pack_id}/export.zip")
async def api_export_pack_zip(pack_id: str):
    data = build_pack_zip_bytes(pack_id)
    if not data:
        raise HTTPException(status_code=404, detail="Pacote não encontrado.")
    return Response(
        content=data,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="vidlens-{pack_id}.zip"'},
    )


# ============================================================================
# ROTAS DIRETAS PARA AGENTES DE IA E LEITORES WEB (/r/{id}, /d/{id}, /ai)
# ============================================================================


@app.get("/r/{pack_id}")
async def ai_reader_page(pack_id: str, request: Request, format: str | None = None):
    pack = load_pack(pack_id)
    if not pack:
        raise HTTPException(status_code=404, detail="Pacote de vídeo não encontrado.")
    base = get_public_base_url(request)
    if _wants_markdown(request, format):
        return PlainTextResponse(build_ai_markdown(pack, base_url=base))
    return HTMLResponse(_render_pack_semantic_html(pack, base_url=base))


@app.get("/d/{dossier_id}")
async def ai_dossier_page(dossier_id: str, request: Request, format: str | None = None):
    dossier = load_dossier(dossier_id)
    if not dossier:
        raise HTTPException(status_code=404, detail="Dossiê de pesquisa não encontrado.")
    base = get_public_base_url(request)
    packs = dossier.get("packs") or []

    md_parts = [
        f"# Dossiê de Pesquisa em Vídeo: {dossier['query']}",
        f"_Gerado pelo VidLens AI • {len(packs)} vídeos analisados com cenas, áudio e transcrição._",
        "",
    ]
    for idx, p in enumerate(packs, start=1):
        md_parts.append(f"---\n\n# VÍDEO {idx} DE {len(packs)}\n")
        md_parts.append(build_ai_markdown(p, base_url=base))
    full_md = "\n".join(md_parts)

    if _wants_markdown(request, format):
        return PlainTextResponse(full_md)

    # Renderiza todos os pacotes em HTML semântico único para IAs lerem de uma vez
    esc = html.escape
    cards_html = []
    for idx, p in enumerate(packs, start=1):
        pid = p["pack_id"]
        cards_html.append(
            f"""
            <section style="background:#131b2e;border:1px solid #1e293b;border-radius:12px;padding:20px;margin:24px 0;">
              <h2>Vídeo {idx}: {esc(p['title'])} ({esc(p['platform'].upper())} • {esc(p['duration_human'])})</h2>
              <p><strong>Fonte Original:</strong> <a href="{esc(p['source_url'])}">{esc(p['source_url'])}</a> | <strong>Canal:</strong> {esc(p['uploader'])} | <a href="{base}/r/{pid}">Abrir pacote individual</a></p>
              <p><strong>Perfil de Áudio:</strong> {esc(str((p.get('audio_telemetry') or {}).get('profile_summary', '—')))}</p>
              <img src="{base}/packs/{pid}/storyboard.jpg" alt="Storyboard {esc(p['title'])}" style="max-width:100%;border-radius:8px;margin:10px 0;" />
              <h3>Transcrição Cronometrada:</h3>
              <ul>
                {''.join(f"<li><code>[{format_duration(s['start'])}]</code> {esc(s['text'])}</li>" for s in (p.get('transcript', {}).get('segments') or [])) or '<li><em>Sem fala detectada</em></li>'}
              </ul>
            </section>
            """
        )

    html_doc = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <title>[Dossiê de Vídeo p/ IA] {esc(dossier['query'])}</title>
  <style>
    body {{ font-family: system-ui, sans-serif; background:#0b0f19; color:#e2e8f0; max-width:980px; margin:0 auto; padding:24px; line-height:1.6; }}
    a {{ color:#38bdf8; }}
    code {{ background:#1e293b; padding:2px 6px; border-radius:4px; color:#bae6fd; }}
  </style>
</head>
<body>
  <p><a href="/">← Voltar ao Painel VidLens AI</a> | <a href="{base}/d/{dossier_id}?format=md">Ver em Markdown Puro</a></p>
  <h1>Dossiê de Pesquisa em Vídeo: {esc(dossier['query'])}</h1>
  <p>Este documento reúne {len(packs)} vídeos convertidos automaticamente em quadros visuais, análise acústica e transcrição sincronizada para leitura por Inteligência Artificial.</p>
  {''.join(cards_html)}
</body>
</html>"""
    return HTMLResponse(html_doc)


@app.get("/ai")
async def instant_ai_url_reader(
    request: Request,
    url: str = Query(..., description="Link do vídeo (YouTube, TikTok, etc.) para converter e ler"),
    max_scenes: int = Query(8, ge=4, le=16),
    format: str | None = None,
):
    """
    Atalho estilo Jina Reader: basta uma IA acessar /ai?url=LINK_DO_VIDEO
    e recebe imediatamente o pacote multimodal legível!
    """
    import asyncio

    loop = asyncio.get_running_loop()
    try:
        pack = await loop.run_in_executor(
            _EXECUTOR, process_video_from_url, url, max_scenes, False
        )
    except VideoConversionError as e:
        raise HTTPException(status_code=400, detail=str(e))
    base = get_public_base_url(request)
    if _wants_markdown(request, format):
        return PlainTextResponse(build_ai_markdown(pack, base_url=base))
    return HTMLResponse(_render_pack_semantic_html(pack, base_url=base))


@app.get("/ai/search")
async def instant_ai_video_search(
    request: Request,
    q: str = Query(..., description="Assunto para a IA pesquisar em vídeos"),
    platform: str = Query("all"),
    convert_top: int = Query(2, ge=0, le=3),
    format: str | None = None,
):
    """
    Endpoint direto para Agentes de IA pesquisarem vídeos por assunto:
    busca vídeos reais e já converte automaticamente os principais resultados!
    """
    import asyncio

    loop = asyncio.get_running_loop()
    results = await loop.run_in_executor(_EXECUTOR, search_videos, q, platform, 6)
    base = get_public_base_url(request)

    converted = []
    for item in results:
        if len(converted) >= convert_top:
            break
        try:
            p = await loop.run_in_executor(
                _EXECUTOR, process_video_from_url, item["url"], 6, False
            )
            converted.append(p)
        except Exception:
            continue

    lines = [
        f"# Pesquisa de Vídeos para IA: \"{q}\"",
        f"Plataforma: {platform} | Resultados encontrados: {len(results)} | Convertidos em detalhe: {len(converted)}",
        "",
        "## Lista de Vídeos Encontrados",
    ]
    for i, r in enumerate(results, 1):
        lines.append(
            f"{i}. **{r['title']}** ({r['platform'].upper()} • {r['duration_human']} • {r['uploader']}) — Original: {r['url']} | Converter p/ IA: {base}/ai?url={r['url']}"
        )

    for idx, p in enumerate(converted, 1):
        lines.append(f"\n---\n\n# ANÁLISE MULTIMODAL DO VÍDEO {idx}\n")
        lines.append(build_ai_markdown(p, base_url=base))

    md_out = "\n".join(lines)
    if _wants_markdown(request, format) or format != "html":
        return PlainTextResponse(md_out)
    return PlainTextResponse(md_out)
