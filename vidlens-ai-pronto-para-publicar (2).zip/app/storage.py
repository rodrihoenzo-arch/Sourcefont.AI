import hashlib
import io
import json
import os
import re
import shutil
import time
import zipfile
from pathlib import Path
from urllib.parse import parse_qs, urlparse

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
PACKS_DIR = DATA_DIR / "packs"
DOSSIERS_DIR = DATA_DIR / "dossiers"
SETTINGS_FILE = DATA_DIR / "settings.json"

PACKS_DIR.mkdir(parents=True, exist_ok=True)
DOSSIERS_DIR.mkdir(parents=True, exist_ok=True)


def normalize_video_url(url: str) -> str:
    """Normaliza URLs equivalentes para evitar conversões duplicadas no cache."""
    url = (url or "").strip()
    if not url:
        return ""
    try:
        parsed = urlparse(url)
        host = parsed.netloc.lower().replace("www.", "").replace("m.", "")
        if host in ("youtube.com", "youtu.be"):
            vid = None
            if host == "youtu.be":
                vid = parsed.path.strip("/").split("/")[0]
            elif "/watch" in parsed.path:
                qs = parse_qs(parsed.query)
                vid = (qs.get("v") or [None])[0]
            elif "/shorts/" in parsed.path:
                vid = parsed.path.split("/shorts/")[1].split("/")[0]
            elif "/embed/" in parsed.path:
                vid = parsed.path.split("/embed/")[1].split("/")[0]
            if vid:
                return f"https://www.youtube.com/watch?v={vid}"
        if "tiktok.com" in host:
            # Remove parâmetros de rastreamento do TikTok
            clean_path = parsed.path.rstrip("/")
            return f"https://www.tiktok.com{clean_path}"
        if "instagram.com" in host:
            clean_path = parsed.path.rstrip("/")
            return f"https://www.instagram.com{clean_path}/"
    except Exception:
        pass
    return url


def make_pack_id(source_key: str) -> str:
    norm = normalize_video_url(source_key) or source_key
    digest = hashlib.sha1(norm.encode("utf-8")).hexdigest()[:10]
    return digest


def get_pack_dir(pack_id: str) -> Path:
    safe_id = re.sub(r"[^a-zA-Z0-9_-]", "", pack_id)
    return PACKS_DIR / safe_id


def load_pack(pack_id: str) -> dict | None:
    pdir = get_pack_dir(pack_id)
    meta_file = pdir / "pack.json"
    if not meta_file.exists():
        return None
    try:
        return json.loads(meta_file.read_text(encoding="utf-8"))
    except Exception:
        return None


def save_pack(pack_id: str, data: dict) -> dict:
    pdir = get_pack_dir(pack_id)
    pdir.mkdir(parents=True, exist_ok=True)
    meta_file = pdir / "pack.json"
    meta_file.write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return data


def list_packs(limit: int = 50) -> list[dict]:
    items = []
    if not PACKS_DIR.exists():
        return items
    for sub in PACKS_DIR.iterdir():
        if not sub.is_dir():
            continue
        meta_file = sub / "pack.json"
        if meta_file.exists():
            try:
                data = json.loads(meta_file.read_text(encoding="utf-8"))
                # Resumo leve para listagem rápida
                items.append(
                    {
                        "pack_id": data.get("pack_id"),
                        "title": data.get("title"),
                        "platform": data.get("platform"),
                        "uploader": data.get("uploader"),
                        "duration_sec": data.get("duration_sec"),
                        "duration_human": data.get("duration_human"),
                        "source_url": data.get("source_url"),
                        "created_at": data.get("created_at", 0),
                        "scenes_count": len(data.get("scenes", [])),
                        "transcript_source": data.get("transcript", {}).get("source"),
                        "thumbnail_url": data.get("cover_image"),
                        "storyboard_url": data.get("storyboard_url"),
                        "audio_url": data.get("audio_url"),
                    }
                )
            except Exception:
                continue
    items.sort(key=lambda x: x.get("created_at", 0), reverse=True)
    return items[:limit]


def delete_pack(pack_id: str) -> bool:
    pdir = get_pack_dir(pack_id)
    if pdir.exists() and pdir.is_dir():
        shutil.rmtree(pdir, ignore_errors=True)
        return True
    return False


def build_pack_zip_bytes(pack_id: str) -> bytes | None:
    pdir = get_pack_dir(pack_id)
    if not (pdir / "pack.json").exists():
        return None
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(pdir):
            for fname in files:
                full = Path(root) / fname
                rel = full.relative_to(pdir)
                zf.write(full, arcname=f"aivp-{pack_id}/{rel}")
    buf.seek(0)
    return buf.read()


def save_dossier(query: str, pack_ids: list[str], platform: str = "all") -> dict:
    did = hashlib.sha1(f"{query}:{time.time()}".encode("utf-8")).hexdigest()[:10]
    dossier = {
        "dossier_id": did,
        "query": query,
        "platform": platform,
        "pack_ids": pack_ids,
        "created_at": time.time(),
    }
    (DOSSIERS_DIR / f"{did}.json").write_text(
        json.dumps(dossier, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return dossier


def load_dossier(dossier_id: str) -> dict | None:
    safe_id = re.sub(r"[^a-zA-Z0-9_-]", "", dossier_id)
    fpath = DOSSIERS_DIR / f"{safe_id}.json"
    if not fpath.exists():
        return None
    try:
        d = json.loads(fpath.read_text(encoding="utf-8"))
        d["packs"] = [p for pid in d.get("pack_ids", []) if (p := load_pack(pid))]
        return d
    except Exception:
        return None


def get_settings() -> dict:
    defaults = {
        "groq_api_key": os.environ.get("GROQ_API_KEY", ""),
        "default_max_scenes": 6,
        "enable_local_whisper": False,
    }
    if SETTINGS_FILE.exists():
        try:
            saved = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
            defaults.update(saved)
        except Exception:
            pass
    return defaults


def update_settings(new_vals: dict) -> dict:
    curr = get_settings()
    if "groq_api_key" in new_vals:
        val = (new_vals["groq_api_key"] or "").strip()
        # Se vier mascarada com ***, mantém a anterior
        if val and not val.startswith("***"):
            curr["groq_api_key"] = val
        elif val == "":
            curr["groq_api_key"] = ""
    if "default_max_scenes" in new_vals:
        curr["default_max_scenes"] = max(4, min(16, int(new_vals["default_max_scenes"])))
    if "enable_local_whisper" in new_vals:
        curr["enable_local_whisper"] = bool(new_vals["enable_local_whisper"])
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    SETTINGS_FILE.write_text(
        json.dumps(curr, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return curr
