import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlparse

import yt_dlp
from ddgs import DDGS

from .storage import load_pack, make_pack_id, normalize_video_url


def format_duration(seconds) -> str:
    if seconds is None:
        return "—"
    try:
        sec = int(float(seconds))
    except Exception:
        # Às vezes DDGS retorna string como "3:45"
        if isinstance(seconds, str) and ":" in seconds:
            return seconds
        return "—"
    if sec < 0:
        return "—"
    hrs, rem = divmod(sec, 3600)
    mins, secs = divmod(rem, 60)
    if hrs > 0:
        return f"{hrs:d}:{mins:02d}:{secs:02d}"
    return f"{mins:02d}:{secs:02d}"


def parse_duration_to_sec(val) -> int | None:
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return int(val)
    if isinstance(val, str):
        parts = val.strip().split(":")
        try:
            if len(parts) == 2:
                return int(parts[0]) * 60 + int(parts[1])
            if len(parts) == 3:
                return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
        except Exception:
            pass
    return None


def detect_platform(url: str) -> str:
    u = (url or "").lower()
    if "youtube.com" in u or "youtu.be" in u:
        return "youtube"
    if "tiktok.com" in u:
        return "tiktok"
    if "instagram.com" in u:
        return "instagram"
    if "vimeo.com" in u:
        return "vimeo"
    return "web"


def _search_youtube(query: str, count: int = 6) -> list[dict]:
    results = []
    opts = {
        "quiet": True,
        "no_warnings": True,
        "extract_flat": True,
        "skip_download": True,
    }
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(f"ytsearch{count}:{query}", download=False)
            for entry in info.get("entries") or []:
                if not entry:
                    continue
                vid_id = entry.get("id")
                url = entry.get("url") or (
                    f"https://www.youtube.com/watch?v={vid_id}" if vid_id else ""
                )
                if url and not url.startswith("http") and vid_id:
                    url = f"https://www.youtube.com/watch?v={vid_id}"
                if not url:
                    continue
                thumbs = entry.get("thumbnails") or []
                thumb = (
                    entry.get("thumbnail")
                    or (thumbs[-1].get("url") if thumbs else None)
                    or (f"https://i.ytimg.com/vi/{vid_id}/hqdefault.jpg" if vid_id else "")
                )
                dur = entry.get("duration")
                results.append(
                    {
                        "title": entry.get("title") or "Vídeo do YouTube",
                        "url": normalize_video_url(url),
                        "platform": "youtube",
                        "uploader": entry.get("uploader")
                        or entry.get("channel")
                        or "YouTube",
                        "duration_sec": parse_duration_to_sec(dur),
                        "duration_human": format_duration(dur),
                        "views": entry.get("view_count"),
                        "thumbnail": thumb,
                        "description": (entry.get("description") or "")[:220],
                    }
                )
    except Exception:
        pass
    return results


def _search_ddgs_platform(query: str, target_platform: str, count: int = 6) -> list[dict]:
    results = []
    seen = set()

    if target_platform == "tiktok":
        vid_query = f"site:tiktok.com {query}"
        txt_query = f"site:tiktok.com/@ {query}"
    elif target_platform == "instagram":
        vid_query = f"site:instagram.com/reel {query}"
        txt_query = f"site:instagram.com/reel/ {query}"
    else:
        vid_query = query
        txt_query = ""

    try:
        with DDGS() as ddgs:
            # 1) Busca nativa de vídeos
            try:
                vids = list(ddgs.videos(vid_query, max_results=max(count * 2, 8)))
            except Exception:
                vids = []

            for v in vids:
                url = (v.get("content") or "").strip()
                if not url.startswith("http"):
                    continue
                plat = detect_platform(url)
                if target_platform == "tiktok" and plat != "tiktok":
                    continue
                if target_platform == "instagram" and plat != "instagram":
                    continue
                # Filtra páginas de perfil sem vídeo específico no TikTok
                if plat == "tiktok" and "/video/" not in url and "vm.tiktok" not in url:
                    continue
                norm = normalize_video_url(url)
                if norm in seen:
                    continue
                seen.add(norm)
                images = v.get("images") or {}
                thumb = images.get("medium") or images.get("large") or images.get("small") or ""
                dur_str = v.get("duration")
                results.append(
                    {
                        "title": v.get("title") or f"Vídeo ({plat.capitalize()})",
                        "url": norm,
                        "platform": plat,
                        "uploader": v.get("uploader") or v.get("publisher") or plat.capitalize(),
                        "duration_sec": parse_duration_to_sec(dur_str),
                        "duration_human": format_duration(dur_str),
                        "views": (v.get("statistics") or {}).get("viewCount"),
                        "thumbnail": thumb,
                        "description": (v.get("description") or "")[:220],
                    }
                )
                if len(results) >= count:
                    break

            # 2) Fallback via busca textual caso haja poucos resultados diretos
            if len(results) < count and txt_query:
                try:
                    txts = list(ddgs.text(txt_query, max_results=10))
                except Exception:
                    txts = []
                for t in txts:
                    url = (t.get("href") or "").strip()
                    if not url.startswith("http"):
                        continue
                    plat = detect_platform(url)
                    if target_platform == "tiktok" and "/video/" not in url:
                        continue
                    if target_platform == "instagram" and "/reel/" not in url and "/p/" not in url:
                        continue
                    norm = normalize_video_url(url)
                    if norm in seen:
                        continue
                    seen.add(norm)
                    # Extrai @usuario do link se possível
                    m_user = re.search(r"/@([^/]+)", norm)
                    uploader = f"@{m_user.group(1)}" if m_user else plat.capitalize()
                    results.append(
                        {
                            "title": t.get("title") or f"Vídeo em {plat.capitalize()}",
                            "url": norm,
                            "platform": plat,
                            "uploader": uploader,
                            "duration_sec": None,
                            "duration_human": "Curto",
                            "views": None,
                            "thumbnail": "",
                            "description": (t.get("body") or "")[:220],
                        }
                    )
                    if len(results) >= count:
                        break
    except Exception:
        pass

    return results


def search_videos(query: str, platform: str = "all", max_results: int = 8) -> list[dict]:
    """Busca vídeos em YouTube, TikTok, Instagram Reels e Web em paralelo."""
    query = (query or "").strip()
    if not query:
        return []
    platform = (platform or "all").lower().strip()
    max_results = max(1, min(20, int(max_results)))

    combined: list[dict] = []

    if platform == "youtube":
        combined = _search_youtube(query, count=max_results)
    elif platform in ("tiktok", "instagram"):
        combined = _search_ddgs_platform(query, platform, count=max_results)
    else:
        # Modo "all": combina YouTube + TikTok + Web em paralelo
        yt_quota = max(4, (max_results * 2) // 3)
        tt_quota = max(3, max_results - yt_quota + 1)
        with ThreadPoolExecutor(max_workers=3) as pool:
            fut_yt = pool.submit(_search_youtube, query, yt_quota)
            fut_tt = pool.submit(_search_ddgs_platform, query, "tiktok", tt_quota)
            fut_ig = pool.submit(_search_ddgs_platform, query, "instagram", 2)
            yt_res = fut_yt.result()
            tt_res = fut_tt.result()
            ig_res = fut_ig.result()

        # Intercala resultados para diversidade de plataformas
        max_len = max(len(yt_res), len(tt_res), len(ig_res), 1)
        for i in range(max_len):
            if i < len(yt_res):
                combined.append(yt_res[i])
            if i < len(tt_res):
                combined.append(tt_res[i])
            if i < len(ig_res):
                combined.append(ig_res[i])

    # Deduplica e anota status do cache local
    final = []
    seen_urls = set()
    for item in combined:
        norm = normalize_video_url(item["url"])
        if norm in seen_urls:
            continue
        seen_urls.add(norm)
        pid = make_pack_id(norm)
        cached = load_pack(pid) is not None
        item["pack_id"] = pid
        item["cached"] = cached
        final.append(item)
        if len(final) >= max_results:
            break

    return final
