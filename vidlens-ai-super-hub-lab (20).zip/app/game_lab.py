import base64
import datetime
import hashlib
import html
import io
import json
import re
import time
import zipfile
from pathlib import Path

from .cloud_vault import fetch_vault_bytes, push_files_to_vault
from .storage import DATA_DIR, get_settings

LAB_DIR = DATA_DIR / "lab"
LAB_DIR.mkdir(parents=True, exist_ok=True)

READABLE_GAME_EXTS = {
    ".glsl",
    ".vert",
    ".frag",
    ".fsh",
    ".vsh",
    ".shader",
    ".json",
    ".cfg",
    ".ini",
    ".txt",
    ".lua",
    ".gd",
    ".js",
    ".properties",
}

PROBE_SCRIPT = r"""
<script id="vidlens-ai-telemetry-probe">
(function() {
  const SESSION_ID = "__SESSION_ID__";
  const logs = [];
  const errors = [];
  let frameCount = 0;
  let fpsSamples = [];
  let lastFpsTime = performance.now();
  let framesSinceLast = 0;

  function pushLog(level, args) {
    try {
      const msg = Array.from(args).map(a => {
        if (typeof a === 'object') { try { return JSON.stringify(a).slice(0, 300); } catch(e) { return String(a); } }
        return String(a);
      }).join(' ');
      logs.push({ t: ((performance.now())/1000).toFixed(2) + 's', level, msg: msg.slice(0, 400) });
      if (logs.length > 80) logs.shift();
      window.parent && window.parent.postMessage({ type: 'vidlens_log', level, msg }, '*');
    } catch (e) {}
  }

  const origLog = console.log, origWarn = console.warn, origErr = console.error;
  console.log = function() { pushLog('INFO', arguments); origLog.apply(console, arguments); };
  console.warn = function() { pushLog('WARN', arguments); origWarn.apply(console, arguments); };
  console.error = function() { pushLog('ERROR', arguments); origErr.apply(console, arguments); };

  window.addEventListener('error', function(ev) {
    const detail = `${ev.message || 'Erro'} (${ev.filename ? ev.filename.split('/').pop() : 'script'}:${ev.lineno || 0}:${ev.colno || 0})`;
    errors.push({ t: ((performance.now())/1000).toFixed(2) + 's', detail });
    pushLog('CRASH', [detail]);
  });

  window.addEventListener('unhandledrejection', function(ev) {
    const detail = 'Promise Rejection: ' + String(ev.reason || 'unknown');
    errors.push({ t: ((performance.now())/1000).toFixed(2) + 's', detail });
    pushLog('CRASH', [detail]);
  });

  function measureLoop(now) {
    frameCount++;
    framesSinceLast++;
    const elapsed = now - lastFpsTime;
    if (elapsed >= 1000) {
      const fps = Math.round((framesSinceLast * 1000) / elapsed);
      fpsSamples.push(fps);
      if (fpsSamples.length > 60) fpsSamples.shift();
      framesSinceLast = 0;
      lastFpsTime = now;
      window.parent && window.parent.postMessage({ type: 'vidlens_fps', fps, frameCount }, '*');
    }
    requestAnimationFrame(measureLoop);
  }
  requestAnimationFrame(measureLoop);

  function captureSnapshotAndSend(tag) {
    try {
      let shotData = null;
      const canvases = document.querySelectorAll('canvas');
      let bestCanvas = null;
      canvases.forEach(c => {
        if (!bestCanvas || (c.width * c.height) > (bestCanvas.width * bestCanvas.height)) bestCanvas = c;
      });
      let canvasInfo = "Sem elemento <canvas> (DOM puro)";
      if (bestCanvas) {
        canvasInfo = `${bestCanvas.width}x${bestCanvas.height}`;
        try { shotData = bestCanvas.toDataURL('image/jpeg', 0.72); } catch (e) {}
      }

      const customState = window.__AI_STATE__ || window.gameState || window.state || null;
      const avgFps = fpsSamples.length ? Math.round(fpsSamples.reduce((a,b)=>a+b,0)/fpsSamples.length) : 0;
      const minFps = fpsSamples.length ? Math.min.apply(null, fpsSamples) : 0;

      fetch(`/api/lab/${SESSION_ID}/telemetry`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tag: tag || 'auto',
          avg_fps: avgFps,
          min_fps: minFps,
          total_frames: frameCount,
          canvas_info: canvasInfo,
          custom_state: customState,
          logs: logs.slice(-40),
          errors: errors.slice(-25),
          screenshot_b64: shotData
        })
      }).catch(()=>{});
    } catch (e) {}
  }

  // Envia telemetria inicial após 2.5s e depois a cada 6s
  setTimeout(() => captureSnapshotAndSend('boot_2.5s'), 2500);
  setInterval(() => captureSnapshotAndSend('live_tick'), 6000);

  // Recebe comandos do Piloto Automático IA (simulação de teclas e cliques)
  window.addEventListener('message', function(ev) {
    if (!ev.data || !ev.data.vidlens_cmd) return;
    const cmd = ev.data.vidlens_cmd;
    if (cmd === 'snapshot') {
      captureSnapshotAndSend('manual_snapshot');
    } else if (cmd === 'autotest') {
      pushLog('AUTOBOT', ['Iniciando bateria automática de comandos (WASD + Setas + Espaço + Cliques)...']);
      const keys = ['KeyW', 'KeyD', 'Space', 'ArrowRight', 'ArrowUp', 'KeyA', 'KeyS'];
      keys.forEach((code, idx) => {
        setTimeout(() => {
          window.dispatchEvent(new KeyboardEvent('keydown', { code, key: code.replace('Key','').toLowerCase(), bubbles: true }));
          document.dispatchEvent(new KeyboardEvent('keydown', { code, key: code.replace('Key','').toLowerCase(), bubbles: true }));
          setTimeout(() => {
            window.dispatchEvent(new KeyboardEvent('keyup', { code, key: code.replace('Key','').toLowerCase(), bubbles: true }));
          }, 180);
        }, idx * 260);
      });
      const c = document.querySelector('canvas') || document.body;
      if (c) {
        const rect = c.getBoundingClientRect();
        const cx = rect.left + rect.width * 0.5, cy = rect.top + rect.height * 0.5;
        c.dispatchEvent(new MouseEvent('mousedown', { clientX: cx, clientY: cy, bubbles: true }));
        c.dispatchEvent(new MouseEvent('mouseup', { clientX: cx, clientY: cy, bubbles: true }));
        c.dispatchEvent(new MouseEvent('click', { clientX: cx, clientY: cy, bubbles: true }));
      }
      setTimeout(() => captureSnapshotAndSend('after_autotest'), 2200);
    }
  });
})();
</script>
"""


def _session_dir(session_id: str) -> Path:
    safe = re.sub(r"[^a-zA-Z0-9_-]", "", session_id)[:24]
    d = LAB_DIR / safe
    (d / "game").mkdir(parents=True, exist_ok=True)
    (d / "shots").mkdir(parents=True, exist_ok=True)
    return d


def _inject_probe_into_html(html_text: str, session_id: str) -> str:
    probe = PROBE_SCRIPT.replace("__SESSION_ID__", session_id)
    if re.search(r"<head[^>]*>", html_text, flags=re.IGNORECASE):
        return re.sub(
            r"(<head[^>]*>)",
            r"\1" + probe,
            html_text,
            count=1,
            flags=re.IGNORECASE,
        )
    return probe + "\n" + html_text


def _inspect_apk_bytes(raw_bytes: bytes, filename: str) -> dict:
    """Desmonta e audita internamente um arquivo Android .apk para leitura por IA."""
    report = {
        "filename": filename,
        "compressed_size_mb": round(len(raw_bytes) / (1024 * 1024), 2),
        "uncompressed_size_mb": 0.0,
        "total_files": 0,
        "engine_detected": "Android Nativo (Java/Kotlin ou C++)",
        "abi_architectures": [],
        "dex_files": [],
        "dex_identifiers_sample": [],
        "heaviest_files": [],
        "extracted_shaders_and_configs": [],
    }
    try:
        with zipfile.ZipFile(io.BytesIO(raw_bytes)) as zf:
            infos = zf.infolist()
            report["total_files"] = len(infos)
            total_uncomp = sum(i.file_size for i in infos)
            report["uncompressed_size_mb"] = round(total_uncomp / (1024 * 1024), 2)

            names = [i.filename for i in infos]
            abis = set()
            dex_list = []
            for n in names:
                m_abi = re.match(r"^lib/([^/]+)/", n)
                if m_abi:
                    abis.add(m_abi.group(1))
                if n.endswith(".dex"):
                    dex_list.append(n)

            report["abi_architectures"] = sorted(abis)
            report["dex_files"] = dex_list

            # Detecta motor gráfico usado no APK
            joined_low = " ".join(names).lower()
            if "libunity.so" in joined_low or "assets/bin/data" in joined_low:
                report["engine_detected"] = "Unity Engine"
            elif "libgodot_android.so" in joined_low or ".pck" in joined_low:
                report["engine_detected"] = "Godot Engine"
            elif "libgdx" in joined_low:
                report["engine_detected"] = "LibGDX"
            elif "libunreal.so" in joined_low or "ue4game" in joined_low:
                report["engine_detected"] = "Unreal Engine"
            elif "flutter_assets" in joined_low:
                report["engine_detected"] = "Flutter / Flame"
            elif any(n.endswith((".glsl", ".vert", ".frag", ".fsh", ".vsh")) for n in names):
                report["engine_detected"] = "Motor Android OpenGL/Vulkan Customizado (com Shaders)"

            # Top 12 arquivos mais pesados do APK
            top_heavy = sorted(infos, key=lambda x: x.file_size, reverse=True)[:12]
            report["heaviest_files"] = [
                {
                    "path": i.filename,
                    "size_kb": round(i.file_size / 1024, 1),
                }
                for i in top_heavy
                if not i.is_dir()
            ]

            # Extrai shaders, configs JSON/CFG e scripts legíveis dentro do APK!
            extracted = []
            for info in infos:
                if info.is_dir() or info.file_size > 48 * 1024 or info.file_size == 0:
                    continue
                ext = Path(info.filename).suffix.lower()
                if ext in READABLE_GAME_EXTS:
                    try:
                        txt = zf.read(info.filename).decode("utf-8", errors="ignore").strip()
                        if txt and len(txt) >= 10 and "\x00" not in txt[:100]:
                            extracted.append(
                                {
                                    "path": info.filename,
                                    "snippet": txt[:2200],
                                }
                            )
                    except Exception:
                        pass
                if len(extracted) >= 10:
                    break
            report["extracted_shaders_and_configs"] = extracted

            # Amostra de nomes de classes/pacotes dentro do classes.dex (para a IA ver a arquitetura de código!)
            if "classes.dex" in names:
                try:
                    dex_raw = zf.read("classes.dex")[: 900 * 1024]
                    pkgs = re.findall(rb"L([a-zA-Z0-9_]+(?:/[a-zA-Z0-9_]+){2,5});", dex_raw)
                    ignore_prefixes = (
                        "android/",
                        "androidx/",
                        "java/",
                        "javax/",
                        "kotlin/",
                        "kotlinx/",
                        "com/google/",
                        "org/intellij/",
                    )
                    custom_classes = []
                    seen_c = set()
                    for raw_c in pkgs:
                        cls_str = raw_c.decode("ascii", errors="ignore")
                        if not cls_str.startswith(ignore_prefixes) and cls_str not in seen_c:
                            seen_c.add(cls_str)
                            custom_classes.append(cls_str.replace("/", "."))
                        if len(custom_classes) >= 35:
                            break
                    report["dex_identifiers_sample"] = custom_classes
                except Exception:
                    pass
    except Exception as e:
        report["parse_error"] = str(e)

    return report


def create_game_lab_session(
    filename: str,
    raw_bytes: bytes,
    title: str = "",
    notes: str = "",
) -> dict:
    now = time.time()
    sid = hashlib.sha1(f"{filename}:{len(raw_bytes)}:{now}".encode("utf-8")).hexdigest()[:10]
    sdir = _session_dir(sid)
    ext = Path(filename).suffix.lower()
    clean_title = (title or Path(filename).stem).strip()[:80] or "Sessão Game Lab"

    mode = "unknown"
    apk_report = None
    play_url = None
    vault_files: list[tuple[str, bytes]] = []

    if ext == ".apk":
        mode = "apk_inspector_and_live_bridge"
        apk_report = _inspect_apk_bytes(raw_bytes, filename)
        if len(raw_bytes) <= 20 * 1024 * 1024:
            (sdir / "game" / "app.apk").write_bytes(raw_bytes)
            vault_files.append((f"lab/{sid}/game/app.apk", raw_bytes))
    elif ext in (".html", ".htm"):
        mode = "web_emulator"
        html_str = raw_bytes.decode("utf-8", errors="replace")
        inst_html = _inject_probe_into_html(html_str, sid)
        out_bytes = inst_html.encode("utf-8")
        (sdir / "game" / "index.html").write_bytes(out_bytes)
        play_url = f"/lab-play/{sid}/index.html"
        vault_files.append((f"lab/{sid}/game/index.html", out_bytes))
    elif ext == ".zip":
        mode = "web_emulator"
        with zipfile.ZipFile(io.BytesIO(raw_bytes)) as zf:
            entry_html = None
            for info in zf.infolist():
                if info.is_dir() or ".." in info.filename:
                    continue
                rel_p = Path(info.filename)
                # Se tudo estiver dentro de 1 pasta raiz, achata 1 nível se necessário
                data_b = zf.read(info.filename)
                if rel_p.name.lower() == "index.html" and entry_html is None:
                    entry_html = rel_p.as_posix()
                    data_b = _inject_probe_into_html(
                        data_b.decode("utf-8", errors="replace"), sid
                    ).encode("utf-8")
                target = sdir / "game" / rel_p
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data_b)
                if len(data_b) <= 15 * 1024 * 1024:
                    vault_files.append((f"lab/{sid}/game/{rel_p.as_posix()}", data_b))
            play_url = f"/lab-play/{sid}/{entry_html or 'index.html'}"
    else:
        raise ValueError("Envie um jogo Web (.html ou .zip HTML5/JS/WebGL) ou um pacote Android (.apk).")

    session_data = {
        "session_id": sid,
        "title": clean_title,
        "filename": filename,
        "notes": (notes or "").strip(),
        "mode": mode,
        "play_url": play_url,
        "created_at": round(now, 2),
        "updated_at": round(now, 2),
        "apk_report": apk_report,
        "telemetry": {
            "pings_count": 0,
            "avg_fps": 0,
            "min_fps": 0,
            "total_frames": 0,
            "canvas_info": "Aguardando execução...",
            "custom_state": None,
            "logs": [],
            "errors": [],
            "screenshots": [],
        },
    }

    meta_bytes = json.dumps(session_data, ensure_ascii=False, indent=2).encode("utf-8")
    (sdir / "session.json").write_bytes(meta_bytes)
    vault_files.append((f"lab/{sid}/session.json", meta_bytes))
    push_files_to_vault(vault_files, f"Create GameLab {sid}: {clean_title}", get_settings())
    return session_data


def load_lab_session(session_id: str) -> dict | None:
    sdir = _session_dir(session_id)
    meta = sdir / "session.json"
    if meta.exists():
        try:
            return json.loads(meta.read_text(encoding="utf-8"))
        except Exception:
            pass
    raw = fetch_vault_bytes(f"lab/{session_id}/session.json", get_settings())
    if raw:
        try:
            data = json.loads(raw.decode("utf-8"))
            meta.write_bytes(raw)
            return data
        except Exception:
            pass
    return None


def ensure_lab_asset(session_id: str, rel_folder: str, rel_file: str) -> Path | None:
    sdir = _session_dir(session_id)
    local_p = (sdir / rel_folder / rel_file).resolve()
    if not str(local_p).startswith(str(sdir.resolve())):
        return None
    if local_p.exists() and local_p.is_file():
        return local_p
    raw = fetch_vault_bytes(f"lab/{session_id}/{rel_folder}/{rel_file}", get_settings())
    if raw is not None:
        local_p.parent.mkdir(parents=True, exist_ok=True)
        local_p.write_bytes(raw)
        return local_p
    return None


def record_lab_telemetry(session_id: str, payload: dict) -> dict | None:
    session = load_lab_session(session_id)
    if not session:
        return None
    sdir = _session_dir(session_id)
    tel = session["telemetry"]
    tel["pings_count"] = int(tel.get("pings_count", 0)) + 1

    if payload.get("avg_fps") is not None:
        tel["avg_fps"] = payload["avg_fps"]
    if payload.get("min_fps") is not None:
        tel["min_fps"] = payload["min_fps"]
    if payload.get("total_frames") is not None:
        tel["total_frames"] = payload["total_frames"]
    if payload.get("canvas_info"):
        tel["canvas_info"] = payload["canvas_info"]
    if payload.get("custom_state") is not None:
        tel["custom_state"] = payload["custom_state"]

    # Mescla logs e erros (útil tanto p/ Emulador Web quanto p/ APK enviando logs ao vivo)
    if payload.get("logs"):
        if isinstance(payload["logs"], list):
            tel["logs"] = payload["logs"][-50:]
        elif isinstance(payload["logs"], str):
            tel["logs"].append({"t": f"ping#{tel['pings_count']}", "level": "APK", "msg": payload["logs"][:400]})
            tel["logs"] = tel["logs"][-50:]

    if payload.get("errors"):
        if isinstance(payload["errors"], list):
            tel["errors"] = payload["errors"][-30:]
        elif isinstance(payload["errors"], str):
            tel["errors"].append({"t": f"ping#{tel['pings_count']}", "detail": payload["errors"][:400]})
            tel["errors"] = tel["errors"][-30:]

    vault_files: list[tuple[str, bytes]] = []
    b64_shot = payload.get("screenshot_b64") or ""
    if b64_shot.startswith("data:image/"):
        try:
            raw_img = base64.b64decode(b64_shot.split(",", 1)[1])
            if 400 < len(raw_img) < 2 * 1024 * 1024:
                shot_idx = (len(tel.get("screenshots") or []) % 6) + 1
                shot_name = f"shot_{shot_idx:02d}.jpg"
                (sdir / "shots" / shot_name).write_bytes(raw_img)
                shot_url = f"/lab-shots/{session_id}/{shot_name}"
                shots = [s for s in (tel.get("screenshots") or []) if s["url"] != shot_url]
                shots.append({"tag": payload.get("tag", "live"), "url": shot_url})
                tel["screenshots"] = shots[-6:]
                vault_files.append((f"lab/{session_id}/shots/{shot_name}", raw_img))
        except Exception:
            pass

    session["updated_at"] = round(time.time(), 2)
    meta_bytes = json.dumps(session, ensure_ascii=False, indent=2).encode("utf-8")
    (sdir / "session.json").write_bytes(meta_bytes)

    # Sincroniza com o Cofre em snapshots manuais/autotest ou a cada 5 pings para não saturar API
    tag = payload.get("tag", "")
    if tag in ("boot_2.5s", "manual_snapshot", "after_autotest", "apk_ping") or tel["pings_count"] % 5 == 1:
        vault_files.append((f"lab/{session_id}/session.json", meta_bytes))
        push_files_to_vault(vault_files, f"Telemetry {session_id} ({tag})", get_settings())

    return session


def build_lab_markdown(session: dict, base_url: str) -> str:
    b = base_url.rstrip("/")
    sid = session["session_id"]
    tel = session.get("telemetry") or {}
    lines = [
        f"# 🕹️ Relatório AI Game Lab: {session['title']}",
        f"- **ID da Sessão:** `{sid}` | **Arquivo:** `{session['filename']}` | **Modo:** `{session['mode']}`",
    ]
    if session.get("notes"):
        lines.append(f"- **Notas / Foco do Teste:** {session['notes']}")
    if session.get("play_url"):
        lines.append(f"- **Emulador Interativo:** {b}{session['play_url']}")

    lines.extend(
        [
            "",
            "## 1. Telemetria de Execução em Tempo Real (FPS, Estado Interno e Erros)",
            f"- ** Leituras Recebidas:** {tel.get('pings_count', 0)} | **FPS Médio:** {tel.get('avg_fps', 0)} fps | **FPS Mínimo:** {tel.get('min_fps', 0)} fps | **Frames Renderizados:** {tel.get('total_frames', 0)}",
            f"- **Canvas / Renderizador:** {tel.get('canvas_info', '—')}",
        ]
    )
    if tel.get("custom_state") is not None:
        lines.append(f"- **Estado Interno (`window.__AI_STATE__`):** `{json.dumps(tel['custom_state'], ensure_ascii=False)}`")

    errs = tel.get("errors") or []
    lines.append("\n### 🚨 Erros Internos / Exceções Capturadas:")
    if errs:
        for e in errs:
            lines.append(f"- `[{e.get('t')}]` **{e.get('detail')}**")
    else:
        lines.append("- ✅ Nenhum erro de execução (`Uncaught Error`) detectado até o momento.")

    logs = tel.get("logs") or []
    lines.append("\n### 📜 Console Interno de Execução (`console.log` / Eventos):")
    if logs:
        for lg in logs[-30:]:
            lines.append(f"- `[{lg.get('t')}]` **{lg.get('level')}:** {lg.get('msg')}")
    else:
        lines.append("- _Sem logs registrados ainda._")

    shots = tel.get("screenshots") or []
    if shots:
        lines.append("\n### 📸 Capturas de Tela da Emulação:")
        for sh in shots:
            lines.append(f"- **{sh.get('tag')}:** ![Captura {sh.get('tag')}]({b}{sh['url']})")

    apk = session.get("apk_report")
    if apk:
        lines.extend(
            [
                "",
                "## 2. Raio-X Interno do Pacote Android (`.apk`)",
                f"- **Motor Gráfico Identificado:** {apk.get('engine_detected')}",
                f"- **Tamanho:** {apk.get('compressed_size_mb')} MB comprimido ({apk.get('uncompressed_size_mb')} MB aberto) | **Total de arquivos:** {apk.get('total_files')}",
                f"- **Arquiteturas Nativas (ABI):** {', '.join(apk.get('abi_architectures') or ['Apenas bytecode DEX/Assets'])}",
                f"- **Como enviar telemetria ao vivo deste APK rodando no celular para esta página:** basta o jogo fazer `GET {b}/lab/{sid}/ping?fps=60&log=NuvensOK&error=`!",
                "",
                "### Classes Principais Encontradas no Bytecode (`classes.dex`):",
            ]
        )
        for cls in (apk.get("dex_identifiers_sample") or [])[:25]:
            lines.append(f"- `{cls}`")

        lines.append("\n### Maiores Arquivos Dentro do APK:")
        for hf in apk.get("heaviest_files") or []:
            lines.append(f"- `{hf['path']}` — {hf['size_kb']} KB")

        if apk.get("extracted_shaders_and_configs"):
            lines.append("\n### Shaders (`.glsl`/`.vert`/`.frag`) e Configs Extraídos do APK:")
            for ex in apk["extracted_shaders_and_configs"]:
                lines.append(f"#### `{ex['path']}`\n```\n{ex['snippet']}\n```")

    return "\n".join(lines)


DEMO_CLOUDS_HTML = """<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="utf-8"/><title>Demo Nuvens Volumétricas 2.5D</title></head>
<body style="margin:0;background:#0a192f;overflow:hidden;font-family:sans-serif;">
<canvas id="sky" width="640" height="360" style="width:100%;height:100vh;display:block;"></canvas>
<script>
const canvas = document.getElementById('sky');
const ctx = canvas.getContext('2d');
let windSpeed = 1.6, coverage = 0.58, t = 0;
const puffs = Array.from({length: 28}, (_, i) => ({
  x: (i * 45) % 700 - 50,
  y: 70 + (i % 4) * 32 + Math.sin(i)*14,
  r: 26 + (i % 5) * 11,
  layer: i % 3
}));
console.log("Simulador de Nuvens iniciado! Use teclas W/S (cobertura) e A/D (vento).");

window.addEventListener('keydown', (e) => {
  if (e.code === 'KeyD' || e.code === 'ArrowRight') { windSpeed += 0.5; console.log("Vento aumentado p/", windSpeed.toFixed(1)); }
  if (e.code === 'KeyA' || e.code === 'ArrowLeft') { windSpeed = Math.max(0.2, windSpeed - 0.5); console.log("Vento reduzido p/", windSpeed.toFixed(1)); }
  if (e.code === 'KeyW' || e.code === 'ArrowUp') { coverage = Math.min(1.0, coverage + 0.1); console.log("Cobertura de nuvens:", coverage.toFixed(2)); }
  if (e.code === 'Space') { console.log("Pulso de turbulência aplicado nas nuvens!"); }
});

function loop() {
  t += 0.016;
  const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
  grad.addColorStop(0, '#1e3a8a');
  grad.addColorStop(0.7, '#38bdf8');
  grad.addColorStop(1, '#bae6fd');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  puffs.forEach((p, idx) => {
    p.x += windSpeed * (0.4 + p.layer * 0.35);
    if (p.x > canvas.width + 80) p.x = -80;
    const rad = p.r * (0.7 + coverage * 0.6);
    const g = ctx.createRadialGradient(p.x, p.y - rad*0.2, rad*0.1, p.x, p.y, rad);
    g.addColorStop(0, 'rgba(255,255,255,0.92)');
    g.addColorStop(0.65, p.layer === 0 ? 'rgba(148,163,184,0.75)' : 'rgba(226,232,240,0.82)');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(p.x, p.y, rad, 0, Math.PI * 2);
    ctx.fill();
  });

  // Terreno simples na base
  ctx.fillStyle = '#14532d';
  ctx.fillRect(0, 315, canvas.width, 45);
  ctx.fillStyle = '#f8fafc';
  ctx.font = 'bold 13px monospace';
  ctx.fillText(`Vento: ${windSpeed.toFixed(1)} m/s | Cobertura: ${(coverage*100).toFixed(0)}% | Puffs: ${puffs.length}`, 14, 24);

  // Expõe variáveis internas em tempo real para a Sonda da IA ler!
  window.__AI_STATE__ = { windSpeed: Number(windSpeed.toFixed(2)), cloudCoverage: Number(coverage.toFixed(2)), activePuffs: puffs.length, simTimeSec: Number(t.toFixed(1)) };
  requestAnimationFrame(loop);
}
loop();
</script>
</body>
</html>
"""
