---
title: VidLens AI
emoji: 🎬
colorFrom: blue
colorTo: indigo
sdk: docker
app_port: 7860
pinned: false
---

# 🎬 VidLens AI — Busca e Conversão de Vídeos para Inteligência Artificial

O **VidLens AI** resolve um dos maiores pontos cegos das IAs atuais: quando uma IA faz pesquisas na internet, ela lê textos e vê imagens, mas não consegue assistir vídeos do YouTube, TikTok ou Reels.

Este sistema **pesquisa vídeos por assunto** e **converte qualquer vídeo automaticamente** em um **Pacote Multimodal Legível por IA**, preservando:
- **Qualidade Visual:** Detecção real de cortes de cena em HD (`scene_01.jpg`, `scene_02.jpg`...) + **Storyboard Cronometrado Único** (`storyboard.jpg`).
- **Áudio Preservado & Análise Acústica:** Áudio em alta qualidade (`audio.mp3`), medição de volume RMS/Pico em dBFS, faixa dinâmica, presença vocal e **Mapa Visual de Forma de Onda + Espectrograma** (`spectrogram.png`).
- **Fala Sincronizada:** Pipeline 100% gratuito em 3 camadas (Legendas Nativas → Groq Whisper Grátis opcional → IA Local `Faster-Whisper` sem chave).

## Rotas Especiais para Agentes de IA
- `/r/{pack_id}` — Página HTML semântica (sem necessidade de JavaScript) com todas as imagens, áudio e transcrição. Adicione `?format=md` para Markdown puro.
- `/d/{dossier_id}` — Dossiê unificado com vários vídeos pesquisados sobre um tema.
- `/ai?url=LINK_DO_VIDEO` — Converte e retorna imediatamente um vídeo legível por IA.
- `/ai/search?q=TEMA&convert_top=2` — Pesquisa vídeos sobre o tema e já devolve os melhores convertidos em texto + imagens.
- `/docs` — Documentação interativa OpenAPI/Swagger para conectar em agentes e automações.
