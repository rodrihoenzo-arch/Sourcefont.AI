"""VidLens AI — Motor de Busca e Conversão Multimodal de Vídeos para IAs."""
__version__ = "1.0.0"
