let currentPack = null;

document.addEventListener("DOMContentLoaded", () => {
  initMagicUrls();
  loadHealthAndSettings();
  loadLibrary();
  setupDragAndDrop();
});

function initMagicUrls() {
  const origin = window.location.origin;
  const elConv = document.getElementById("magicUrlConvert");
  const elSearch = document.getElementById("magicUrlSearch");
  if (elConv) {
    elConv.textContent = `${origin}/ai?url=https://www.youtube.com/watch?v=qx4wK0WZteQ`;
  }
  if (elSearch) {
    elSearch.textContent = `${origin}/ai/search?q=inteligencia+artificial+brasil&convert_top=2`;
  }
}

function showToast(msg) {
  const t = document.getElementById("toastMsg");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2600);
}

function setLoading(active, title = "Processando...", sub = "Aguarde alguns segundos...") {
  const box = document.getElementById("loadingBox");
  document.getElementById("loadingTitle").textContent = title;
  document.getElementById("loadingSub").textContent = sub;
  box.classList.toggle("active", active);
  if (active) hideError();
}

function showError(msg) {
  const box = document.getElementById("errorBox");
  box.textContent = "⚠️ " + msg;
  box.classList.add("active");
}

function hideError() {
  const box = document.getElementById("errorBox");
  box.classList.remove("active");
}

function switchMainTab(tabId) {
  document.querySelectorAll(".nav-tab").forEach((b) => {
    b.classList.toggle("active", b.dataset.tab === tabId);
  });
  document.querySelectorAll(".panel").forEach((p) => {
    p.classList.toggle("active", p.id === tabId);
  });
  if (tabId === "tab-library") {
    loadLibrary();
  }
}

function switchSubTab(subId) {
  document.querySelectorAll(".sub-tab").forEach((b) => {
    b.classList.toggle("active", b.dataset.sub === subId);
  });
  document.querySelectorAll(".sub-view").forEach((v) => {
    v.classList.toggle("active", v.id === subId);
  });
}

function openModal(id) {
  document.getElementById(id).classList.add("active");
}

function closeModal(id) {
  document.getElementById(id).classList.remove("active");
}

function escapeHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

async function loadHealthAndSettings() {
  try {
    const [hRes, sRes] = await Promise.all([
      fetch("/api/health"),
      fetch("/api/settings"),
    ]);
    if (hRes.ok) {
      const h = await hRes.json();
      const txt = document.getElementById("engineStatusText");
      if (h.groq_configured) {
        txt.textContent = "Motor Ativo • Turbo Groq + FFmpeg";
      } else {
        txt.textContent = `Motor 100% Gratuito Ativo (${h.cached_packs} no cache)`;
      }
    }
    if (sRes.ok) {
      const s = await sRes.json();
      document.getElementById("cfgMaxScenes").value = String(s.default_max_scenes || 8);
      document.getElementById("cfgLocalWhisper").checked = Boolean(s.enable_local_whisper);
      if (s.groq_api_key_masked) {
        document.getElementById("cfgGroqKey").value = s.groq_api_key_masked;
      }
    }
  } catch (e) {
    console.error(e);
  }
}

async function saveSettings() {
  const maxScenes = parseInt(document.getElementById("cfgMaxScenes").value, 10) || 8;
  const localWhisper = document.getElementById("cfgLocalWhisper").checked;
  const groqKey = document.getElementById("cfgGroqKey").value.trim();

  try {
    const res = await fetch("/api/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        default_max_scenes: maxScenes,
        enable_local_whisper: localWhisper,
        groq_api_key: groqKey,
      }),
    });
    if (res.ok) {
      closeModal("settingsModal");
      showToast("Configurações salvas com sucesso!");
      loadHealthAndSettings();
    }
  } catch (e) {
    showError("Não foi possível salvar as configurações.");
  }
}

function quickSearch(query, platform) {
  document.getElementById("searchInput").value = query;
  document.getElementById("searchPlatform").value = platform || "all";
  runVideoSearch();
}

async function runVideoSearch() {
  const q = document.getElementById("searchInput").value.trim();
  const platform = document.getElementById("searchPlatform").value;
  if (!q) {
    showError("Digite um assunto para pesquisar vídeos.");
    return;
  }

  document.getElementById("dossierBanner").style.display = "none";
  setLoading(true, `Pesquisando vídeos sobre "${q}"...`, "Consultando YouTube, TikTok e fontes de vídeo da web...");

  try {
    const res = await fetch(`/api/search?q=${encodeURIComponent(q)}&platform=${encodeURIComponent(platform)}&max_results=9`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Falha na pesquisa.");
    renderSearchResults(data.results || []);
  } catch (e) {
    showError(e.message || "Erro ao pesquisar vídeos.");
  } finally {
    setLoading(false);
  }
}

function renderSearchResults(items) {
  const grid = document.getElementById("searchResultsGrid");
  if (!items.length) {
    grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;color:var(--text-secondary);padding:28px;">Nenhum vídeo encontrado para essa busca. Tente termos mais amplos.</div>`;
    return;
  }

  grid.innerHTML = items
    .map((v) => {
      const platClass = `plat-${escapeHtml(v.platform || "web")}`;
      const thumbHtml = v.thumbnail
        ? `<img src="${escapeHtml(v.thumbnail)}" alt="Miniatura" loading="lazy" onerror="this.style.display='none'" />`
        : `<div class="thumb-placeholder">🎬 ${escapeHtml((v.platform || " Vídeo").toUpperCase())}</div>`;
      const actionBtn = v.cached
        ? `<button class="btn btn-emerald btn-sm" style="flex:1" onclick="openPackById('${escapeHtml(v.pack_id)}')">⚡ Abrir do Cache</button>`
        : `<button class="btn btn-primary btn-sm" style="flex:1" onclick="convertVideoUrl('${escapeHtml(v.url)}')">✨ Converter p/ IA</button>`;

      return `
      <div class="video-card">
        <div>
          <div class="thumb-wrap">
            ${thumbHtml}
            <span class="plat-badge ${platClass}">${escapeHtml(v.platform)}</span>
            <span class="dur-badge">${escapeHtml(v.duration_human || "—")}</span>
          </div>
          <div class="card-body">
            <h4 class="card-title" title="${escapeHtml(v.title)}">${escapeHtml(v.title)}</h4>
            <div class="card-meta">👤 ${escapeHtml(v.uploader || "Canal")}</div>
          </div>
        </div>
        <div class="card-footer">
          ${actionBtn}
          <a href="${escapeHtml(v.url)}" target="_blank" rel="noopener" class="btn btn-secondary btn-sm" title="Ver original">↗</a>
        </div>
      </div>`;
    })
    .join("");
}

async function runBatchResearch() {
  const q = document.getElementById("searchInput").value.trim();
  const platform = document.getElementById("searchPlatform").value;
  if (!q) {
    showError("Digite um assunto primeiro para gerar o Dossiê Automático para IA.");
    return;
  }

  setLoading(
    true,
    `Montando Dossiê de Pesquisa em Vídeo para "${q}"...`,
    "Buscando vídeos relevantes, extraindo cenas HD, preservando áudio e unificando transcrições..."
  );

  try {
    const res = await fetch("/api/research-batch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: q, platform, top_n: 2, max_scenes: 6 }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Falha ao criar dossiê.");

    const banner = document.getElementById("dossierBanner");
    const fullUrl = `${window.location.origin}/d/${data.dossier_id}`;
    banner.style.display = "block";
    banner.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
        <div>
          <strong style="color:#f3e8ff;font-size:1rem;">📑 Dossiê Multimodal Pronto (${data.packs.length} vídeos unificados)!</strong>
          <div style="font-size:0.85rem;color:#e9d5ff;margin-top:3px;">Envie este link único para sua IA ler todos os vídeos pesquisados de uma vez: <code>${escapeHtml(fullUrl)}</code></div>
        </div>
        <div style="display:flex;gap:8px;">
          <button class="btn btn-purple btn-sm" onclick="navigator.clipboard.writeText('${escapeHtml(fullUrl)}');showToast('Link do Dossiê copiado!')">🔗 Copiar Link do Dossiê</button>
          <a href="/d/${escapeHtml(data.dossier_id)}" target="_blank" class="btn btn-secondary btn-sm">Abrir Dossiê Completo</a>
        </div>
      </div>
    `;

    if (data.packs && data.packs.length > 0) {
      await openPackById(data.packs[0].pack_id);
    }
    loadHealthAndSettings();
  } catch (e) {
    showError(e.message || "Erro na pesquisa em lote.");
  } finally {
    setLoading(false);
  }
}

async function convertDirectUrl() {
  const url = document.getElementById("directUrlInput").value.trim();
  const maxScenes = parseInt(document.getElementById("directScenesCount").value, 10) || 8;
  if (!url) {
    showError("Cole um link de vídeo válido.");
    return;
  }
  await convertVideoUrl(url, maxScenes);
}

async function convertVideoUrl(url, maxScenes = 8) {
  setLoading(
    true,
    "Convertendo vídeo para formato Multimodal IA...",
    "Baixando mídia, detectando mudanças de cena HD, medindo espectro de áudio e sincronizando transcrição..."
  );

  try {
    const res = await fetch("/api/convert", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url, max_scenes: maxScenes, force_refresh: false }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Falha ao converter vídeo.");
    renderPackViewer(data);
    loadHealthAndSettings();
  } catch (e) {
    showError(e.message || "Erro ao converter vídeo.");
  } finally {
    setLoading(false);
  }
}

function setupDragAndDrop() {
  const dz = document.getElementById("uploadDropzone");
  if (!dz) return;
  dz.addEventListener("dragover", (e) => {
    e.preventDefault();
    dz.classList.add("dragover");
  });
  dz.addEventListener("dragleave", () => dz.classList.remove("dragover"));
  dz.addEventListener("drop", (e) => {
    e.preventDefault();
    dz.classList.remove("dragover");
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  });
}

async function handleFileUpload(file) {
  if (!file) return;
  setLoading(
    true,
    `Convertendo arquivo "${file.name}"...`,
    "Extraindo cenas HD, áudio preservado, espectrograma e transcrevendo fala gratuitamente..."
  );

  const formData = new FormData();
  formData.append("file", file);
  formData.append("max_scenes", document.getElementById("cfgMaxScenes").value || "8");

  try {
    const res = await fetch("/api/upload", {
      method: "POST",
      body: formData,
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Falha no upload.");
    renderPackViewer(data);
    loadHealthAndSettings();
  } catch (e) {
    showError(e.message || "Erro ao enviar vídeo.");
  } finally {
    setLoading(false);
    document.getElementById("videoFileInput").value = "";
  }
}

async function openPackById(packId) {
  setLoading(true, "Abrindo pacote do cache...", "Carregamento instantâneo...");
  try {
    const res = await fetch(`/api/packs/${encodeURIComponent(packId)}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Pacote não encontrado.");
    renderPackViewer(data);
  } catch (e) {
    showError(e.message);
  } finally {
    setLoading(false);
  }
}

function closePackViewer() {
  document.getElementById("packViewer").classList.remove("active");
}

function renderPackViewer(pack) {
  currentPack = pack;
  const viewer = document.getElementById("packViewer");
  viewer.classList.add("active");

  const platBadge = document.getElementById("pvPlatform");
  platBadge.className = `plat-badge plat-${pack.platform || "web"}`;
  platBadge.textContent = (pack.platform || "web").toUpperCase();

  document.getElementById("pvTitle").textContent = pack.title || "Vídeo Convertido";
  const specs = pack.video_specs || {};
  document.getElementById("pvMeta").innerHTML = `
    👤 <strong>${escapeHtml(pack.uploader)}</strong> &nbsp;•&nbsp;
    ⏱️ ${escapeHtml(pack.duration_human)} &nbsp;•&nbsp;
    🎞️ ${specs.width || 0}×${specs.height || 0} (${(pack.scenes || []).length} cenas HD) &nbsp;•&nbsp;
    🗣️ ${escapeHtml((pack.transcript || {}).source || "—")}
  `;

  document.getElementById("pvReaderOpenBtn").href = `/r/${pack.pack_id}`;
  document.getElementById("pvStoryboardDownload").href = pack.storyboard_url;
  document.getElementById("pvZipDownload").href = `/api/packs/${pack.pack_id}/export.zip`;

  // 1. Cenas
  const scenesGrid = document.getElementById("pvScenesGrid");
  scenesGrid.innerHTML = (pack.scenes || [])
    .map((sc) => {
      const vis = sc.visual || {};
      const aud = sc.audio || {};
      const dots = (vis.dominant_colors || [])
        .map((c) => `<span class="color-dot" style="background:${escapeHtml(c)}" title="${escapeHtml(c)}"></span>`)
        .join("");
      const speech = sc.spoken_text
        ? `"${escapeHtml(sc.spoken_text)}"`
        : `<em style="color:var(--text-muted)">Sem fala transcrita neste trecho</em>`;

      return `
      <div class="scene-card">
        <a href="${escapeHtml(sc.image_url)}" target="_blank" title="Clique para abrir o quadro em tamanho real">
          <img src="${escapeHtml(sc.image_url)}" alt="Cena ${sc.index}" loading="lazy" />
        </a>
        <div class="scene-info">
          <div class="scene-header">
            <strong>Cena ${String(sc.index).padStart(2, "0")}</strong>
            <span class="scene-time">${escapeHtml(sc.time_range)}</span>
          </div>
          <div class="scene-speech">${speech}</div>
          <div class="scene-telemetry">
            <span>🔊 ${escapeHtml(aud.energy_label || "—")} (${aud.rms_db ?? "—"} dB)</span>
            <span>✨ Nitidez: ${vis.sharpness_score ?? 0}/100</span>
            <span class="color-dots">${dots}</span>
          </div>
        </div>
      </div>`;
    })
    .join("");

  // 2. Storyboard
  document.getElementById("pvStoryboardImg").src = `${pack.storyboard_url}?t=${Date.now()}`;

  // 3. Áudio & Espectrograma
  const audTel = pack.audio_telemetry || {};
  const metricsEl = document.getElementById("pvAudioMetrics");
  const playerWrap = document.getElementById("pvAudioPlayerWrap");
  const specImg = document.getElementById("pvSpectrogramImg");

  if (audTel.available) {
    metricsEl.innerHTML = `
      <div class="metric-box"><div class="metric-label">Volume Médio (RMS)</div><div class="metric-val">${audTel.rms_db} dBFS</div></div>
      <div class="metric-box"><div class="metric-label">Pico Máximo</div><div class="metric-val">${audTel.peak_db} dBFS</div></div>
      <div class="metric-box"><div class="metric-label">Atividade Sonora</div><div class="metric-val">${audTel.active_sound_pct}%</div></div>
      <div class="metric-box"><div class="metric-label">Presença Vocal</div><div class="metric-val">${audTel.voice_band_energy_pct}%</div></div>
      <div class="metric-box" style="grid-column:1/-1"><div class="metric-label">Diagnóstico Acústico p/ IA</div><div class="metric-val" style="font-size:0.98rem;color:#6ee7b7">${escapeHtml(audTel.profile_summary)}</div></div>
    `;
    playerWrap.innerHTML = pack.audio_url
      ? `<div style="background:var(--bg-elevated);padding:12px 16px;border-radius:10px;border:1px solid var(--border);display:flex;flex-wrap:wrap;align-items:center;gap:14px;">
           <strong>🎧 Áudio Original Preservado:</strong>
           <audio controls src="${escapeHtml(pack.audio_url)}" style="flex:1;min-width:240px;"></audio>
           <a href="${escapeHtml(pack.audio_url)}" download="audio-${pack.pack_id}.mp3" class="btn btn-secondary btn-sm">Baixar MP3</a>
         </div>`
      : "";
    specImg.style.display = "block";
    specImg.src = `${pack.spectrogram_url}?t=${Date.now()}`;
  } else {
    metricsEl.innerHTML = `<div class="metric-box"><div class="metric-val">Sem faixa de áudio detectada</div></div>`;
    playerWrap.innerHTML = "";
    specImg.style.display = "none";
  }

  // 4. Markdown p/ IA (reescreve links usando window.location.origin atual)
  const origin = window.location.origin;
  const mdText = (pack.ai_markdown || "").replace(/https?:\/\/[^/\s)]+\/packs\//g, `${origin}/packs/`);
  document.getElementById("pvMarkdownArea").value = mdText;

  switchSubTab("sub-scenes");
  viewer.scrollIntoView({ behavior: "smooth", block: "start" });
}

function copyPromptForAI() {
  if (!currentPack) return;
  const md = document.getElementById("pvMarkdownArea").value;
  const readerUrl = `${window.location.origin}/r/${currentPack.pack_id}`;
  const prompt = `Analise este vídeo convertido pelo VidLens AI (Link com imagens das cenas e áudio: ${readerUrl}). Abaixo estão todos os dados multimodais extraídos (metadados, análise acústica, cenas cronometradas e transcrição):\n\n${md}`;
  navigator.clipboard.writeText(prompt);
  showToast("📋 Relatório + Prompt copiados! Cole direto na sua IA.");
}

function copyReaderLink() {
  if (!currentPack) return;
  const url = `${window.location.origin}/r/${currentPack.pack_id}`;
  navigator.clipboard.writeText(url);
  showToast("🔗 Link Leitor IA copiado!");
}

async function loadLibrary() {
  const grid = document.getElementById("libraryGrid");
  if (!grid) return;
  try {
    const res = await fetch("/api/packs");
    const data = await res.json();
    const items = data.packs || [];
    if (!items.length) {
      grid.innerHTML = `<div style="grid-column:1/-1;color:var(--text-secondary);padding:18px;background:var(--bg-elevated);border-radius:10px;text-align:center;">Ainda não há vídeos convertidos no cache. Pesquise um tema na primeira aba e clique em "Converter p/ IA"!</div>`;
      return;
    }
    grid.innerHTML = items
      .map(
        (p) => `
      <div class="video-card">
        <div>
          <div class="thumb-wrap">
            <img src="${escapeHtml(p.thumbnail_url || p.storyboard_url)}" alt="Cena" loading="lazy" />
            <span class="plat-badge plat-${escapeHtml(p.platform || "web")}">${escapeHtml(p.platform)}</span>
            <span class="dur-badge">${escapeHtml(p.duration_human || "—")}</span>
          </div>
          <div class="card-body">
            <h4 class="card-title">${escapeHtml(p.title)}</h4>
            <div class="card-meta">👤 ${escapeHtml(p.uploader)} • ${p.scenes_count} cenas</div>
          </div>
        </div>
        <div class="card-footer">
          <button class="btn btn-primary btn-sm" style="flex:1" onclick="openPackById('${escapeHtml(p.pack_id)}')">Abrir Pacote IA</button>
          <button class="btn btn-secondary btn-sm" onclick="removePack('${escapeHtml(p.pack_id)}')" title="Excluir do cache">🗑️</button>
        </div>
      </div>`
      )
      .join("");
  } catch (e) {
    console.error(e);
  }
}

async function removePack(packId) {
  await fetch(`/api/packs/${encodeURIComponent(packId)}`, { method: "DELETE" });
  showToast("Removido do cache.");
  loadLibrary();
  loadHealthAndSettings();
}
