import html
import os
import re
from pathlib import Path

import httpx

_WHISPER_MODEL = None


def _time_str_to_sec(t_str: str) -> float:
    t_str = t_str.strip().replace(",", ".")
    parts = t_str.split(":")
    try:
        if len(parts) == 3:
            return float(parts[0]) * 3600 + float(parts[1]) * 60 + float(parts[2])
        if len(parts) == 2:
            return float(parts[0]) * 60 + float(parts[1])
    except Exception:
        pass
    return 0.0


def parse_vtt_or_srt(content: str) -> list[dict]:
    """Faz parsing limpo de legendas .vtt ou .srt removendo tags e repetições."""
    lines = content.splitlines()
    segments = []
    time_re = re.compile(
        r"(\d{1,2}:\d{2}:\d{2}[\.,]\d{1,3}|\d{2}:\d{2}[\.,]\d{1,3})\s*-->\s*(\d{1,2}:\d{2}:\d{2}[\.,]\d{1,3}|\d{2}:\d{2}[\.,]\d{1,3})"
    )

    curr_start = None
    curr_end = None
    curr_text_lines = []

    def flush():
        nonlocal curr_start, curr_end, curr_text_lines
        if curr_start is not None and curr_text_lines:
            raw = " ".join(curr_text_lines)
            # Remove tags VTT como <c>, <00:01.000>, etc.
            clean = re.sub(r"<[^>]+>", "", raw)
            clean = html.unescape(clean)
            clean = re.sub(r"\s+", " ", clean).strip()
            if clean:
                # Evita duplicação de legendas rolantes (comum em auto-captions)
                if segments and clean == segments[-1]["text"]:
                    segments[-1]["end"] = max(segments[-1]["end"], curr_end)
                elif segments and clean.startswith(segments[-1]["text"]) and (
                    curr_start - segments[-1]["start"] < 4.0
                ):
                    segments[-1]["text"] = clean
                    segments[-1]["end"] = max(segments[-1]["end"], curr_end)
                else:
                    segments.append(
                        {
                            "start": round(curr_start, 2),
                            "end": round(curr_end, 2),
                            "text": clean,
                        }
                    )
        curr_start = None
        curr_end = None
        curr_text_lines = []

    for line in lines:
        s = line.strip()
        if not s:
            flush()
            continue
        if s.startswith("WEBVTT") or s.startswith("Kind:") or s.startswith("Language:") or s.startswith("NOTE"):
            continue
        if s.isdigit() and curr_start is None:
            continue
        m = time_re.search(s)
        if m:
            flush()
            curr_start = _time_str_to_sec(m.group(1))
            curr_end = _time_str_to_sec(m.group(2))
            continue
        if curr_start is not None:
            curr_text_lines.append(s)

    flush()
    return segments


def _extract_youtube_api_transcript(video_id: str) -> dict | None:
    if not video_id:
        return None
    try:
        from youtube_transcript_api import YouTubeTranscriptApi

        ytt = YouTubeTranscriptApi()
        t_list = ytt.list(video_id)
        preferred = ["pt", "pt-BR", "pt-PT", "en", "en-US", "es"]

        chosen = None
        try:
            chosen = t_list.find_manually_created_transcript(preferred)
        except Exception:
            try:
                chosen = t_list.find_generated_transcript(preferred)
            except Exception:
                for tr in t_list:
                    chosen = tr
                    break

        if not chosen:
            return None

        fetched = chosen.fetch()
        segments = []
        for item in fetched:
            txt = getattr(item, "text", None) or (item.get("text") if isinstance(item, dict) else "")
            start = float(getattr(item, "start", 0.0) if not isinstance(item, dict) else item.get("start", 0.0))
            dur = float(getattr(item, "duration", 2.0) if not isinstance(item, dict) else item.get("duration", 2.0))
            clean = html.unescape(re.sub(r"\s+", " ", (txt or "")).strip())
            if clean:
                segments.append(
                    {
                        "start": round(start, 2),
                        "end": round(start + dur, 2),
                        "text": clean,
                    }
                )
        if not segments:
            return None
        lang = getattr(chosen, "language_code", "auto")
        is_gen = getattr(chosen, "is_generated", False)
        return {
            "source": f"Legenda Nativa YouTube ({lang}{' auto' if is_gen else ''})",
            "language": lang,
            "segments": segments,
            "full_text": " ".join(s["text"] for s in segments),
        }
    except Exception:
        return None


def _extract_from_subtitle_files(sub_files: list[Path]) -> dict | None:
    if not sub_files:
        return None

    # Prioriza arquivos em português -> inglês -> demais
    def rank_sub(p: Path) -> int:
        n = p.name.lower()
        if ".pt" in n or ".por" in n:
            return 0
        if ".en" in n or ".eng" in n:
            return 1
        if ".es" in n or ".spa" in n:
            return 2
        return 3

    ordered = sorted(sub_files, key=rank_sub)
    for spath in ordered:
        try:
            raw = spath.read_text(encoding="utf-8", errors="ignore")
            segs = parse_vtt_or_srt(raw)
            if segs:
                # Extrai código de idioma do nome do arquivo (ex: vid.por-BR.vtt)
                parts = spath.name.split(".")
                lang = parts[-2] if len(parts) >= 3 else "auto"
                return {
                    "source": f"Legenda Extraída ({lang})",
                    "language": lang,
                    "segments": segs,
                    "full_text": " ".join(s["text"] for s in segs),
                }
        except Exception:
            continue
    return None


def _transcribe_groq_whisper(audio_path: Path, api_key: str) -> dict | None:
    if not api_key or not audio_path.exists():
        return None
    # Limite de 24MB da API gratuita da Groq
    if audio_path.stat().st_size > 24 * 1024 * 1024:
        return None
    try:
        with open(audio_path, "rb") as f:
            resp = httpx.post(
                "https://api.groq.com/openai/v1/audio/transcriptions",
                headers={"Authorization": f"Bearer {api_key}"},
                files={"file": (audio_path.name, f, "audio/mpeg")},
                data={
                    "model": "whisper-large-v3-turbo",
                    "response_format": "verbose_json",
                },
                timeout=60.0,
            )
        if resp.status_code != 200:
            return None
        data = resp.json()
        segs = []
        for s in data.get("segments") or []:
            txt = (s.get("text") or "").strip()
            if txt:
                segs.append(
                    {
                        "start": round(float(s.get("start", 0)), 2),
                        "end": round(float(s.get("end", 0)), 2),
                        "text": txt,
                    }
                )
        full = (data.get("text") or "").strip() or " ".join(x["text"] for x in segs)
        if not full:
            return None
        return {
            "source": "Whisper Large-v3 Turbo (Groq Grátis)",
            "language": data.get("language") or "auto",
            "segments": segs,
            "full_text": full,
        }
    except Exception:
        return None


def _transcribe_local_whisper(audio_wav_path: Path) -> dict | None:
    if not audio_wav_path or not audio_wav_path.exists():
        return None
    model = None
    try:
        import gc
        from faster_whisper import WhisperModel

        model = WhisperModel(
            "tiny",
            device="cpu",
            compute_type="int8",
            cpu_threads=1,
        )
        segments_gen, info = model.transcribe(
            str(audio_wav_path),
            beam_size=1,
            vad_filter=True,
        )
        segs = []
        for s in segments_gen:
            txt = (s.text or "").strip()
            if txt:
                segs.append(
                    {
                        "start": round(float(s.start), 2),
                        "end": round(float(s.end), 2),
                        "text": txt,
                    }
                )
            # Evita travar a CPU/RAM em servidores gratuitos de 512MB: limita a ~5 min locais
            if s.end > 300:
                break
        lang = info.language or "auto"
        del model
        gc.collect()
        if not segs:
            return None
        return {
            "source": f"IA Local Gratuita (Faster-Whisper • {lang})",
            "language": lang,
            "segments": segs,
            "full_text": " ".join(x["text"] for x in segs),
        }
    except Exception:
        if model is not None:
            del model
        return None


def extract_best_transcript(
    platform: str,
    video_id: str | None,
    sub_files: list[Path],
    audio_mp3_path: Path | None,
    audio_wav_path: Path | None,
    groq_api_key: str = "",
    enable_local_whisper: bool = True,
) -> dict:
    """
    Pipeline de 3 camadas 100% gratuito para extrair a fala sincronizada no tempo:
    1) Legendas nativas da plataforma (YouTube API / arquivos VTT do TikTok, etc.)
    2) Groq Whisper API Gratuita (se o usuário configurou chave opcional)
    3) Faster-Whisper Local na CPU (100% offline, zero chaves)
    """
    # 1A. YouTube Transcript API (instantâneo)
    if platform == "youtube" and video_id:
        res = _extract_youtube_api_transcript(video_id)
        if res and res.get("segments"):
            return res

    # 1B. Arquivos .vtt / .srt baixados pelo yt-dlp (TikTok, YouTube, Vimeo...)
    res = _extract_from_subtitle_files(sub_files)
    if res and res.get("segments"):
        return res

    # 2. Groq API opcional (grátis)
    if groq_api_key and audio_mp3_path and audio_mp3_path.exists():
        res = _transcribe_groq_whisper(audio_mp3_path, groq_api_key)
        if res and res.get("full_text"):
            return res

    # 3. Faster-Whisper local na CPU (100% gratuito e sem chave)
    if enable_local_whisper and audio_wav_path and audio_wav_path.exists():
        res = _transcribe_local_whisper(audio_wav_path)
        if res and res.get("full_text"):
            return res

    return {
        "source": "Sem fala detectada / Apenas áudio instrumental ou ambiente",
        "language": "—",
        "segments": [],
        "full_text": "",
    }
